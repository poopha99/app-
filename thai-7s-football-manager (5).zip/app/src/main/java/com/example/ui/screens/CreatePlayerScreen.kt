package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.GameStateManager
import com.example.model.Player
import com.example.model.Position
import com.example.ui.components.PlayerCardView
import com.example.ui.theme.*

@Composable
fun CreatePlayerScreen(
    gameStateManager: GameStateManager,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val currentCustom = gameStateManager.customPlayer

    var name by remember { mutableStateOf(currentCustom?.name ?: "ศุภกิตติ์ เท้าชั่งทอง") }
    var nickname by remember { mutableStateOf(currentCustom?.nickname ?: "กิตติ์ จอมทัพเดินสาย") }
    var position by remember { mutableStateOf(currentCustom?.position ?: Position.FW) }
    var numberStr by remember { mutableStateOf((currentCustom?.number ?: 7).toString()) }
    var preferredFoot by remember { mutableStateOf(currentCustom?.preferredFoot ?: "ขวา") }

    var pace by remember { mutableFloatStateOf((currentCustom?.pace ?: 91).toFloat()) }
    var shooting by remember { mutableFloatStateOf((currentCustom?.shooting ?: 89).toFloat()) }
    var passing by remember { mutableFloatStateOf((currentCustom?.passing ?: 85).toFloat()) }
    var dribbling by remember { mutableFloatStateOf((currentCustom?.dribbling ?: 88).toFloat()) }
    var defending by remember { mutableFloatStateOf((currentCustom?.defending ?: 62).toFloat()) }
    var physical by remember { mutableFloatStateOf((currentCustom?.physical ?: 80).toFloat()) }

    val skillsList = listOf(
        "ลูกยิงไซด์ก้อยสะเด่า 30 หลา",
        "จรวดทางเรียบ สปีด 99 ฉีกแผงหลัง",
        "คลึงบอลสไตล์ฟุตซอล 7 คน ลอดดาก",
        "ดักทางระดับอาจารย์ เสียบสกัดติดพื้น",
        "วางบอลยาวชั่งทอง ข้ามฟากเข้าตีน",
        "กวินทร์บินได้ บินปัดเสียบสามเหลี่ยม"
    )
    var selectedSkill by remember { mutableStateOf(currentCustom?.signatureSkill ?: skillsList[0]) }

    val avatarColors = listOf(0xFF2979FF, 0xFF00E676, 0xFFFF3D57, 0xFFFFD600, 0xFF9C27B0)
    var selectedColor by remember { mutableStateOf(currentCustom?.customAvatarColor ?: avatarColors[0]) }

    // Live preview player instance
    val tempPlayer = remember(name, nickname, position, numberStr, preferredFoot, pace, shooting, passing, dribbling, defending, physical, selectedSkill, selectedColor) {
        val num = numberStr.toIntOrNull() ?: 7
        val p = Player(
            id = currentCustom?.id ?: "preview_custom",
            name = name.ifEmpty { "นักเตะในฝัน" },
            nickname = nickname.ifEmpty { "ดาวเตะ" },
            position = position,
            number = num,
            age = 22,
            preferredFoot = preferredFoot,
            ovr = 0,
            pace = pace.toInt(),
            shooting = shooting.toInt(),
            passing = passing.toInt(),
            dribbling = dribbling.toInt(),
            defending = defending.toInt(),
            physical = physical.toInt(),
            signatureSkill = selectedSkill,
            isCustom = true,
            customAvatarColor = selectedColor
        )
        p.copy(ovr = p.calculateOvr())
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(StadiumDarkBg)
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Column {
                Text(
                    text = "⭐ สร้างนักฟุตบอลคนโปรดของคุณ (1 คน)",
                    color = Color.White,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Black
                )
                Text(
                    text = "สร้างซูเปอร์สตาร์ที่คุณชอบ กำหนดค่าพลังและท่าไม้ตาย พร้อมลงเล่นเป็นตัวจริงทันที!",
                    color = TextSecondary,
                    fontSize = 12.sp
                )
            }
        }

        item {
            // Live Card Preview
            PlayerCardView(
                player = tempPlayer,
                modifier = Modifier.fillMaxWidth()
            )
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = StadiumCardBg),
                border = androidx.compose.foundation.BorderStroke(1.dp, StadiumCardBorder)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "👤 ข้อมูลส่วนตัวของนักเตะ",
                        color = ElectricCyan,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )

                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("ชื่อ-นามสกุล นักเตะ") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = nickname,
                        onValueChange = { nickname = it },
                        label = { Text("ฉายา / ชื่อเล่นสไตล์ฟุตบอลเดินสาย (เช่น โจ้ เท้าไฟ)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = numberStr,
                            onValueChange = { if (it.length <= 2) numberStr = it },
                            label = { Text("เบอร์เสื้อ (1-99)") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )

                        // Preferred Foot
                        Column(modifier = Modifier.weight(1f)) {
                            Text("เท้าข้างถนัด", color = TextSecondary, fontSize = 11.sp)
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                listOf("ขวา", "ซ้าย", "สองเท้า").forEach { foot ->
                                    FilterChip(
                                        selected = preferredFoot == foot,
                                        onClick = { preferredFoot = foot },
                                        label = { Text(foot, fontSize = 11.sp) },
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = ElectricCyan,
                                            selectedLabelColor = Color.Black
                                        )
                                    )
                                }
                            }
                        }
                    }

                    // Position Selector
                    Text("ตำแหน่งถนัดในสนาม 7 คน:", color = TextSecondary, fontSize = 11.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Position.values().forEach { pos ->
                            FilterChip(
                                selected = position == pos,
                                onClick = { position = pos },
                                label = { Text("${pos.shortName} (${pos.thName})", fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = TournamentGold,
                                    selectedLabelColor = Color.Black
                                )
                            )
                        }
                    }
                }
            }
        }

        item {
            // Attribute Sliders
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = StadiumCardBg),
                border = androidx.compose.foundation.BorderStroke(1.dp, StadiumCardBorder)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "⚡ จัดสรรแต้มค่าพลัง (Attributes)",
                            color = TournamentGold,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "OVR รวม: ${tempPlayer.ovr}",
                            color = NeonLime,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Black
                        )
                    }

                    StatSlider("ความเร็วและสปีด (Pace)", pace) { pace = it }
                    StatSlider("การจบสกอร์ยิงประตู (Shooting)", shooting) { shooting = it }
                    StatSlider("การจ่ายบอล & แอสซิสต์ (Passing)", passing) { passing = it }
                    StatSlider("การเลี้ยงบอลกินตัว (Dribbling)", dribbling) { dribbling = it }
                    StatSlider("เกมรับ & แย่งบอล (Defending)", defending) { defending = it }
                    StatSlider("ความแข็งแกร่ง & ฟิตเนส (Physical)", physical) { physical = it }
                }
            }
        }

        item {
            // Signature Skill Selection
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = StadiumCardBg),
                border = androidx.compose.foundation.BorderStroke(1.dp, StadiumCardBorder)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "🌟 เลือกท่าไม้ตายเฉพาะตัว (Signature Skill)",
                        color = ElectricCyan,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    skillsList.forEach { skill ->
                        val isSelected = selectedSkill == skill
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 3.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) Color(0xFF1E3A5F) else Color(0xFF0F172A))
                                .clickable { selectedSkill = skill }
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "⭐ $skill",
                                color = if (isSelected) TournamentGold else Color.White,
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                            if (isSelected) {
                                Icon(Icons.Default.Check, contentDescription = "Selected", tint = TournamentGold)
                            }
                        }
                    }
                }
            }
        }

        item {
            // Save Button
            Button(
                onClick = {
                    val num = numberStr.toIntOrNull() ?: 7
                    val saved = gameStateManager.saveCustomPlayer(
                        name = name.ifEmpty { "นักเตะในฝัน" },
                        nickname = nickname.ifEmpty { "จอมทัพเดินสาย" },
                        position = position,
                        number = num,
                        preferredFoot = preferredFoot,
                        pace = pace.toInt(),
                        shooting = shooting.toInt(),
                        passing = passing.toInt(),
                        dribbling = dribbling.toInt(),
                        defending = defending.toInt(),
                        physical = physical.toInt(),
                        skill = selectedSkill,
                        avatarColor = selectedColor
                    )
                    Toast.makeText(context, "สร้างและบรรจุ ${saved.name} (${saved.nickname}) เข้าสู่ทีมตัวจริงแล้ว!", Toast.LENGTH_LONG).show()
                },
                colors = ButtonDefaults.buttonColors(containerColor = NeonLime),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("save_custom_player_button")
            ) {
                Icon(Icons.Default.PersonAdd, contentDescription = "Save", tint = Color.Black)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "💾 บันทึกนักเตะ & ส่งลงสนามตัวจริง",
                    color = Color.Black,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Black
                )
            }

            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

@Composable
private fun StatSlider(label: String, value: Float, onValueChange: (Float) -> Unit) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label, color = TextSecondary, fontSize = 11.sp)
            Text("${value.toInt()}", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = 50f..99f,
            colors = SliderDefaults.colors(thumbColor = ElectricCyan, activeTrackColor = ElectricCyan)
        )
    }
}
