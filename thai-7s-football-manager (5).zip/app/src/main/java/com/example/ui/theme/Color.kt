package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// eFootball Sports Theme Colors
val StadiumDarkBg = Color(0xFF090D16)
val StadiumCardBg = Color(0xFF131B2E)
val StadiumCardBorder = Color(0xFF223152)

val ElectricCyan = Color(0xFF00E5FF)
val NeonLime = Color(0xFF00E676)
val TournamentGold = Color(0xFFFFD700)
val NeonCoral = Color(0xFFFF3D57)
val DeepBlue = Color(0xFF0D47A1)

val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xFF90A4AE)
val TextMuted = Color(0xFF607D8B)

val PitchGrassLight = Color(0xFF1B5E20)
val PitchGrassDark = Color(0xFF144D19)
val PitchLine = Color(0x99FFFFFF)
