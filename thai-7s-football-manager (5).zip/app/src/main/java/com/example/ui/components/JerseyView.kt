package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.model.KitConfig
import com.example.model.KitPattern

@Composable
fun JerseyView(
    config: KitConfig,
    modifier: Modifier = Modifier,
    size: Dp = 120.dp,
    playerNumber: Int? = 10,
    playerName: String? = null
) {
    val primaryColor = Color(config.primaryColor)
    val secondaryColor = Color(config.secondaryColor)
    val accentColor = Color(config.accentColor)
    val numberColor = Color(config.numberColor)

    val height = size * 1.25f

    Box(
        modifier = modifier
            .size(width = size, height = height)
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0xFF0F172A))
            .border(1.5.dp, Color(0xFF334155), RoundedCornerShape(16.dp)),
        contentAlignment = Alignment.Center
    ) {
        if (!config.customImageUri.isNullOrEmpty()) {
            // Display User Uploaded Kit Graphic
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                AsyncImage(
                    model = ImageRequest.Builder(LocalContext.current)
                        .data(config.customImageUri)
                        .crossfade(true)
                        .build(),
                    contentDescription = "Custom Team Kit",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxSize()
                        .clip(RoundedCornerShape(14.dp))
                )

                // Dark gradient overlay to ensure player number & name contrast
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.5f))
                            )
                        )
                )

                // Custom kit tag
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(6.dp)
                        .background(Color(0xCC00E5FF), RoundedCornerShape(6.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "CUSTOM",
                        color = Color.Black,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Number overlay
                if (playerNumber != null) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.align(Alignment.Center)
                    ) {
                        Text(
                            text = "$playerNumber",
                            color = numberColor,
                            fontSize = (size.value * 0.32f).sp,
                            fontWeight = FontWeight.Black
                        )
                        if (!playerName.isNullOrEmpty()) {
                            Text(
                                text = playerName,
                                color = numberColor,
                                fontSize = (size.value * 0.12f).sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1
                            )
                        }
                    }
                }
            }
        } else {
            // Procedurally rendered jersey pattern
            Canvas(modifier = Modifier.fillMaxSize()) {
                val w = this.size.width
                val h = this.size.height

                // Base color
                drawRect(primaryColor)

                // Draw chosen kit pattern
                when (config.pattern) {
                    KitPattern.SOLID -> {
                        // Subtle center stripe accent
                        drawRect(
                            color = secondaryColor.copy(alpha = 0.3f),
                            topLeft = Offset(w * 0.46f, 0f),
                            size = Size(w * 0.08f, h)
                        )
                    }
                    KitPattern.STRIPES -> {
                        val stripeWidth = w / 7f
                        for (i in 0..6 step 2) {
                            drawRect(
                                color = secondaryColor,
                                topLeft = Offset(i * stripeWidth, 0f),
                                size = Size(stripeWidth, h)
                            )
                        }
                    }
                    KitPattern.SASH -> {
                        val path = Path().apply {
                            moveTo(0f, h * 0.1f)
                            lineTo(w, h * 0.85f)
                            lineTo(w, h * 0.95f)
                            lineTo(0f, h * 0.2f)
                            close()
                        }
                        drawPath(path, secondaryColor)
                    }
                    KitPattern.HOOPS -> {
                        val hoopHeight = h / 8f
                        for (i in 0..7 step 2) {
                            drawRect(
                                color = secondaryColor,
                                topLeft = Offset(0f, i * hoopHeight),
                                size = Size(w, hoopHeight)
                            )
                        }
                    }
                    KitPattern.THAI_CHEVRON -> {
                        val count = 4
                        val stepY = h / (count + 1)
                        for (i in 1..count) {
                            val path = Path().apply {
                                val cy = i * stepY
                                moveTo(0f, cy)
                                lineTo(w * 0.5f, cy + (stepY * 0.35f))
                                lineTo(w, cy)
                                lineTo(w, cy + (stepY * 0.2f))
                                lineTo(w * 0.5f, cy + (stepY * 0.55f))
                                lineTo(0f, cy + (stepY * 0.2f))
                                close()
                            }
                            drawPath(path, secondaryColor)
                        }
                    }
                    KitPattern.NEON_CYBER -> {
                        // Cyber grid lines
                        drawLine(
                            color = secondaryColor,
                            start = Offset(w * 0.2f, 0f),
                            end = Offset(w * 0.2f, h),
                            strokeWidth = 3f
                        )
                        drawLine(
                            color = secondaryColor,
                            start = Offset(w * 0.8f, 0f),
                            end = Offset(w * 0.8f, h),
                            strokeWidth = 3f
                        )
                        drawLine(
                            color = accentColor,
                            start = Offset(0f, h * 0.35f),
                            end = Offset(w, h * 0.35f),
                            strokeWidth = 3f
                        )
                    }
                }

                // Collar & Shoulder trim
                val collarPath = Path().apply {
                    moveTo(w * 0.3f, 0f)
                    lineTo(w * 0.5f, h * 0.18f)
                    lineTo(w * 0.7f, 0f)
                    close()
                }
                drawPath(collarPath, accentColor)

                // Chest sponsor box subtle outline
                drawRoundRect(
                    color = Color.Black.copy(alpha = 0.25f),
                    topLeft = Offset(w * 0.18f, h * 0.45f),
                    size = Size(w * 0.64f, h * 0.15f),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(8f, 8f)
                )
            }

            // Sponsor text & Player Number
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
                modifier = Modifier.fillMaxSize()
            ) {
                Spacer(modifier = Modifier.height(size * 0.2f))

                // Chest sponsor
                Text(
                    text = "THAILAND 7s",
                    color = accentColor,
                    fontSize = (size.value * 0.08f).coerceAtLeast(8f).sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 0.5.sp
                )

                Spacer(modifier = Modifier.height(4.dp))

                if (playerNumber != null) {
                    Text(
                        text = "$playerNumber",
                        color = numberColor,
                        fontSize = (size.value * 0.30f).sp,
                        fontWeight = FontWeight.Black
                    )
                }

                if (!playerName.isNullOrEmpty()) {
                    Text(
                        text = playerName,
                        color = numberColor,
                        fontSize = (size.value * 0.10f).coerceAtLeast(9f).sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1
                    )
                }
            }
        }
    }
}
