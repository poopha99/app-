package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.FormationType
import com.example.model.Player
import com.example.model.Position
import com.example.ui.theme.PitchGrassDark
import com.example.ui.theme.PitchGrassLight

data class PitchPlayerPos(
    val xPct: Float,
    val yPct: Float,
    val player: Player?,
    val isHome: Boolean
)

@Composable
fun ThaiPitchView(
    starters: List<Player>,
    formation: FormationType,
    ballX: Float, // 0..100
    ballY: Float, // 0..100
    possessionHome: Boolean,
    activePlayerName: String,
    modifier: Modifier = Modifier,
    homeTeamColor: Long = 0xFF00E5FF,
    awayTeamColor: Long = 0xFFFF3D57
) {
    val animBallX by animateFloatAsState(targetValue = ballX, animationSpec = tween(700), label = "ballX")
    val animBallY by animateFloatAsState(targetValue = ballY, animationSpec = tween(700), label = "ballY")

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(230.dp)
            .clip(RoundedCornerShape(16.dp))
            .border(2.dp, Color(0xFF263238), RoundedCornerShape(16.dp))
            .background(PitchGrassDark)
    ) {
        // Draw Field Graphics
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height

            // Turf stripes
            val stripeCount = 9
            val stripeW = w / stripeCount
            for (i in 0 until stripeCount) {
                if (i % 2 == 0) {
                    drawRect(
                        color = PitchGrassLight,
                        topLeft = Offset(i * stripeW, 0f),
                        size = Size(stripeW, h)
                    )
                }
            }

            val linePaint = Color.White.copy(alpha = 0.55f)
            val lineStroke = Stroke(width = 2.5f)

            // Outer Boundary
            drawRect(
                color = linePaint,
                topLeft = Offset(w * 0.04f, h * 0.05f),
                size = Size(w * 0.92f, h * 0.90f),
                style = lineStroke
            )

            // Halfway Line
            drawLine(
                color = linePaint,
                start = Offset(w * 0.5f, h * 0.05f),
                end = Offset(w * 0.5f, h * 0.95f),
                strokeWidth = 2.5f
            )

            // Center Circle & Spot
            drawCircle(
                color = linePaint,
                radius = h * 0.20f,
                center = Offset(w * 0.5f, h * 0.5f),
                style = lineStroke
            )
            drawCircle(
                color = linePaint,
                radius = 4f,
                center = Offset(w * 0.5f, h * 0.5f),
                style = Fill
            )

            // Left Penalty Area (Home Defense)
            drawRect(
                color = linePaint,
                topLeft = Offset(w * 0.04f, h * 0.25f),
                size = Size(w * 0.16f, h * 0.50f),
                style = lineStroke
            )
            // Goal Post Left
            drawRect(
                color = Color.White.copy(alpha = 0.8f),
                topLeft = Offset(w * 0.015f, h * 0.38f),
                size = Size(w * 0.025f, h * 0.24f),
                style = lineStroke
            )

            // Right Penalty Area (Away Defense)
            drawRect(
                color = linePaint,
                topLeft = Offset(w * 0.80f, h * 0.25f),
                size = Size(w * 0.16f, h * 0.50f),
                style = lineStroke
            )
            // Goal Post Right
            drawRect(
                color = Color.White.copy(alpha = 0.8f),
                topLeft = Offset(w * 0.96f, h * 0.38f),
                size = Size(w * 0.025f, h * 0.24f),
                style = lineStroke
            )
        }

        // Compute 7-Player positions based on formation
        // Left side = Home (attacking rightwards)
        val homePositions = getFormationCoords(formation, isHome = true)
        val awayPositions = getFormationCoords(FormationType.F_2_3_1, isHome = false)

        // Render Home 7 Players
        homePositions.forEachIndexed { index, (xPct, yPct) ->
            val player = starters.getOrNull(index)
            val isBallCarrier = possessionHome && (player?.name == activePlayerName || (activePlayerName.isEmpty() && index == 3))

            PlayerToken(
                xPct = xPct,
                yPct = yPct,
                number = player?.number ?: (index + 1),
                name = player?.nickname ?: "นักเตะ",
                isBallCarrier = isBallCarrier,
                color = Color(homeTeamColor),
                modifier = Modifier.align(Alignment.TopStart)
            )
        }

        // Render Away 7 Players
        awayPositions.forEachIndexed { index, (xPct, yPct) ->
            val isBallCarrier = !possessionHome && index == 6

            PlayerToken(
                xPct = xPct,
                yPct = yPct,
                number = index + 1,
                name = "",
                isBallCarrier = isBallCarrier,
                color = Color(awayTeamColor),
                modifier = Modifier.align(Alignment.TopStart)
            )
        }

        // Ball with glowing shadow
        Box(
            modifier = Modifier
                .offset(
                    x = ((animBallX / 100f) * 290).dp,
                    y = ((animBallY / 100f) * 190).dp
                )
                .size(14.dp)
                .shadow(6.dp, RoundedCornerShape(7.dp))
                .clip(RoundedCornerShape(7.dp))
                .background(Color.White)
                .border(1.5.dp, Color.Black, RoundedCornerShape(7.dp))
        )

        // Live Possession & Active Player Pill at top center
        Box(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 8.dp)
                .clip(RoundedCornerShape(20.dp))
                .background(Color(0xCC000000))
                .border(1.dp, if (possessionHome) Color(homeTeamColor) else Color(awayTeamColor), RoundedCornerShape(20.dp))
                .padding(horizontal = 10.dp, vertical = 3.dp)
        ) {
            Text(
                text = if (possessionHome) "⚡ $activePlayerName กำลังพาบอล" else "🛡️ คู่แข่งกำลังบุกเจาะแนวรับ",
                color = if (possessionHome) Color(homeTeamColor) else Color(awayTeamColor),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun PlayerToken(
    xPct: Float,
    yPct: Float,
    number: Int,
    name: String,
    isBallCarrier: Boolean,
    color: Color,
    modifier: Modifier = Modifier
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier.offset(
            x = (xPct * 3.1f).dp,
            y = (yPct * 1.8f).dp
        )
    ) {
        Box(
            modifier = Modifier
                .size(if (isBallCarrier) 20.dp else 16.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(color)
                .border(
                    width = if (isBallCarrier) 2.dp else 1.dp,
                    color = if (isBallCarrier) Color.Yellow else Color.White,
                    shape = RoundedCornerShape(10.dp)
                ),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "$number",
                color = Color.Black,
                fontSize = if (isBallCarrier) 10.sp else 9.sp,
                fontWeight = FontWeight.Black
            )
        }

        if (name.isNotEmpty() && isBallCarrier) {
            Text(
                text = name,
                color = Color.White,
                fontSize = 8.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                modifier = Modifier
                    .background(Color(0xBB000000), RoundedCornerShape(4.dp))
                    .padding(horizontal = 2.dp)
            )
        }
    }
}

private fun getFormationCoords(formation: FormationType, isHome: Boolean): List<Pair<Float, Float>> {
    // Return (X%, Y%) for 7 players
    // GK, 2 DF, 3 MF, 1 FW (default for 2-3-1)
    val rawCoords = when (formation) {
        FormationType.F_2_3_1 -> listOf(
            Pair(7f, 50f),   // GK
            Pair(24f, 30f),  // DF Left
            Pair(24f, 70f),  // DF Right
            Pair(38f, 25f),  // MF Left Winger
            Pair(40f, 50f),  // MF Center Playmaker
            Pair(38f, 75f),  // MF Right Winger
            Pair(46f, 50f)   // FW Striker
        )
        FormationType.F_3_2_1 -> listOf(
            Pair(7f, 50f),   // GK
            Pair(23f, 25f),  // DF Left
            Pair(21f, 50f),  // DF Center
            Pair(23f, 75f),  // DF Right
            Pair(37f, 38f),  // MF
            Pair(37f, 62f),  // MF
            Pair(46f, 50f)   // FW
        )
        FormationType.F_2_2_2 -> listOf(
            Pair(7f, 50f),   // GK
            Pair(24f, 32f),  // DF
            Pair(24f, 68f),  // DF
            Pair(36f, 30f),  // MF
            Pair(36f, 70f),  // MF
            Pair(46f, 35f),  // FW
            Pair(46f, 65f)   // FW
        )
        FormationType.F_1_3_2 -> listOf(
            Pair(7f, 50f),   // GK
            Pair(22f, 50f),  // Sweeper DF
            Pair(35f, 25f),  // MF
            Pair(35f, 50f),  // MF
            Pair(35f, 75f),  // MF
            Pair(46f, 35f),  // FW
            Pair(46f, 65f)   // FW
        )
        FormationType.F_2_1_2_1 -> listOf(
            Pair(7f, 50f),   // GK
            Pair(24f, 30f),  // DF
            Pair(24f, 70f),  // DF
            Pair(32f, 50f),  // DMF Holding
            Pair(39f, 25f),  // Winger
            Pair(39f, 75f),  // Winger
            Pair(46f, 50f)   // ST
        )
    }

    return if (isHome) {
        rawCoords
    } else {
        // Mirror horizontally for away team (50..100%)
        rawCoords.map { (x, y) -> Pair(100f - x, y) }
    }
}
