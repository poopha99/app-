package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Player
import com.example.model.Position
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.TournamentGold

@Composable
fun PlayerCardView(
    player: Player,
    modifier: Modifier = Modifier,
    isCompact: Boolean = false
) {
    val cardBrush = if (player.isCustom) {
        Brush.linearGradient(
            listOf(Color(0xFF8E24AA), Color(0xFF3949AB), Color(0xFF1E88E5))
        )
    } else if (player.ovr >= 87) {
        Brush.linearGradient(
            listOf(Color(0xFFD4AF37), Color(0xFF855A06), Color(0xFF1A1A1A))
        )
    } else {
        Brush.linearGradient(
            listOf(Color(0xFF2E3D52), Color(0xFF162032), Color(0xFF0F172A))
        )
    }

    val posColor = when (player.position) {
        Position.GK -> Color(0xFFFF9800)
        Position.DF -> Color(0xFF2196F3)
        Position.MF -> Color(0xFF4CAF50)
        Position.FW -> Color(0xFFF44336)
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(cardBrush)
            .border(
                1.5.dp,
                if (player.isCustom) ElectricCyan else if (player.ovr >= 87) TournamentGold else Color(0xFF455A64),
                RoundedCornerShape(16.dp)
            )
            .padding(if (isCompact) 10.dp else 14.dp)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // Header: OVR + Position + Custom badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "${player.ovr}",
                        color = Color.White,
                        fontSize = if (isCompact) 20.sp else 26.sp,
                        fontWeight = FontWeight.Black
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(posColor)
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = player.position.shortName,
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (player.isCustom) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(Color(0xFFE91E63))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "CUSTOM",
                                color = Color.White,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = "🇹🇭", fontSize = 16.sp)
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Player Avatar / Number Circle
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .size(if (isCompact) 36.dp else 44.dp)
                        .clip(CircleShape)
                        .background(Color(player.customAvatarColor).copy(alpha = 0.3f))
                        .border(1.5.dp, Color.White.copy(alpha = 0.6f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "#${player.number}",
                        color = Color.White,
                        fontSize = if (isCompact) 13.sp else 16.sp,
                        fontWeight = FontWeight.Black
                    )
                }

                Spacer(modifier = Modifier.width(10.dp))

                Column {
                    Text(
                        text = player.name,
                        color = Color.White,
                        fontSize = if (isCompact) 13.sp else 15.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1
                    )
                    Text(
                        text = "\"${player.nickname}\"",
                        color = TournamentGold,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        maxLines = 1
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // 6-Attribute Grid: PAC, SHO, PAS, DRI, DEF, PHY
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0x55000000), RoundedCornerShape(8.dp))
                    .padding(vertical = 4.dp, horizontal = 6.dp),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                StatCol("PAC", player.pace)
                StatCol("SHO", player.shooting)
                StatCol("PAS", player.passing)
                StatCol("DRI", player.dribbling)
                StatCol("DEF", player.defending)
                StatCol("PHY", player.physical)
            }

            if (!isCompact) {
                Spacer(modifier = Modifier.height(8.dp))
                // Signature Skill
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0x33FFFFFF), RoundedCornerShape(6.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Star,
                        contentDescription = "Skill",
                        tint = TournamentGold,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = player.signatureSkill,
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1
                    )
                }
            }
        }
    }
}

@Composable
private fun StatCol(label: String, value: Int) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = label,
            color = Color(0xFFB0BEC5),
            fontSize = 9.sp,
            fontWeight = FontWeight.Medium
        )
        Text(
            text = "$value",
            color = if (value >= 85) TournamentGold else Color.White,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
        )
    }
}
