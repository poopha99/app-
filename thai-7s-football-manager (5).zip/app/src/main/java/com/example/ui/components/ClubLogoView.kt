package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.SportsSoccer
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.LogoConfig
import com.example.model.LogoEmblem
import com.example.model.LogoShape

@Composable
fun ClubLogoView(
    config: LogoConfig,
    modifier: Modifier = Modifier,
    size: Dp = 64.dp
) {
    val primaryColor = Color(config.primaryColor)
    val accentColor = Color(config.accentColor)

    Box(
        modifier = modifier.size(size),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = this.size.width
            val h = this.size.height

            val path = Path()
            when (config.shape) {
                LogoShape.SHIELD -> {
                    path.moveTo(w * 0.1f, h * 0.1f)
                    path.lineTo(w * 0.9f, h * 0.1f)
                    path.lineTo(w * 0.9f, h * 0.55f)
                    path.cubicTo(w * 0.9f, h * 0.85f, w * 0.5f, h * 0.98f, w * 0.5f, h * 0.98f)
                    path.cubicTo(w * 0.5f, h * 0.98f, w * 0.1f, h * 0.85f, w * 0.1f, h * 0.55f)
                    path.close()
                }
                LogoShape.CIRCLE -> {
                    path.addOval(androidx.compose.ui.geometry.Rect(w * 0.05f, h * 0.05f, w * 0.95f, h * 0.95f))
                }
                LogoShape.DIAMOND -> {
                    path.moveTo(w * 0.5f, h * 0.05f)
                    path.lineTo(w * 0.95f, h * 0.5f)
                    path.lineTo(w * 0.5f, h * 0.95f)
                    path.lineTo(w * 0.05f, h * 0.5f)
                    path.close()
                }
                LogoShape.HEXAGON -> {
                    path.moveTo(w * 0.5f, h * 0.05f)
                    path.lineTo(w * 0.95f, h * 0.28f)
                    path.lineTo(w * 0.95f, h * 0.72f)
                    path.lineTo(w * 0.5f, h * 0.95f)
                    path.lineTo(w * 0.05f, h * 0.72f)
                    path.lineTo(w * 0.05f, h * 0.28f)
                    path.close()
                }
            }

            // Fill background with primary color gradient
            drawPath(
                path = path,
                brush = Brush.verticalGradient(
                    colors = listOf(primaryColor, primaryColor.copy(alpha = 0.8f))
                ),
                style = Fill
            )

            // Outer border with accent color
            drawPath(
                path = path,
                brush = Brush.verticalGradient(
                    colors = listOf(accentColor, accentColor.copy(alpha = 0.6f))
                ),
                style = Stroke(width = (w * 0.06f).coerceAtLeast(2f))
            )

            // Inner subtle shield line
            val innerPath = Path()
            innerPath.addPath(path, Offset.Zero)
            drawPath(
                path = innerPath,
                color = Color.White.copy(alpha = 0.2f),
                style = Stroke(width = (w * 0.02f).coerceAtLeast(1f))
            )
        }

        // Center Emblem & Short Name
        Box(
            modifier = Modifier.size(size * 0.55f),
            contentAlignment = Alignment.Center
        ) {
            when (config.emblem) {
                LogoEmblem.LIGHTNING -> {
                    Icon(
                        imageVector = Icons.Default.Bolt,
                        contentDescription = "Bolt",
                        tint = accentColor,
                        modifier = Modifier.fillMaxSize(0.75f)
                    )
                }
                LogoEmblem.FOOTBALL -> {
                    Icon(
                        imageVector = Icons.Default.SportsSoccer,
                        contentDescription = "Soccer",
                        tint = accentColor,
                        modifier = Modifier.fillMaxSize(0.75f)
                    )
                }
                LogoEmblem.ELEPHANT -> {
                    Text(
                        text = "🐘",
                        fontSize = (size.value * 0.32f).sp
                    )
                }
                LogoEmblem.TIGER -> {
                    Text(
                        text = "🐯",
                        fontSize = (size.value * 0.32f).sp
                    )
                }
                LogoEmblem.EAGLE -> {
                    Text(
                        text = "🦅",
                        fontSize = (size.value * 0.32f).sp
                    )
                }
                LogoEmblem.DRAGON -> {
                    Text(
                        text = "🐉",
                        fontSize = (size.value * 0.32f).sp
                    )
                }
            }
        }

        // Short Name Tag at bottom
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .size(width = size * 0.75f, height = size * 0.3f),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = config.shortName,
                color = accentColor,
                fontWeight = FontWeight.Black,
                fontSize = (size.value * 0.18f).sp,
                letterSpacing = 1.sp
            )
        }
    }
}
