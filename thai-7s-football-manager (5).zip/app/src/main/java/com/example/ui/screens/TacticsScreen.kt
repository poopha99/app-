package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.GameStateManager
import com.example.model.*
import com.example.ui.components.PlayerCardView
import com.example.ui.components.ThaiPitchView
import com.example.ui.theme.*

@Composable
fun TacticsScreen(
    gameStateManager: GameStateManager,
    modifier: Modifier = Modifier
) {
    val club = gameStateManager.club
    val starters = gameStateManager.getStarters()
    val bench = gameStateManager.getBench()

    var selectedPlayerToSwap by remember { mutableStateOf<Player?>(null) }
    var selectedPlayerDetail by remember { mutableStateOf<Player?>(null) }

    var tempo by remember(club.tactics.gameTempo) { mutableFloatStateOf(club.tactics.gameTempo.toFloat()) }
    var press by remember(club.tactics.pressingIntensity) { mutableFloatStateOf(club.tactics.pressingIntensity.toFloat()) }
    var width by remember(club.tactics.pitchWidth) { mutableFloatStateOf(club.tactics.pitchWidth.toFloat()) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(StadiumDarkBg)
            .padding(14.dp)
    ) {
        item {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "📋 แผนการเล่น 7 คน (Tactics & Lineup)",
                        color = Color.White,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Black
                    )
                    Text(
                        text = "จัด 7 ผู้เล่นตัวจริง กำหนดแผนการเล่นและสไตล์การบุก",
                        color = TextSecondary,
                        fontSize = 12.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Formation Selector Chips (2-3-1, 3-2-1, etc.)
            Text(
                text = "⚡ รูปแบบแผนการเล่น (7-a-side Formations)",
                color = ElectricCyan,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(6.dp))

            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(FormationType.values()) { f ->
                    val isSelected = club.tactics.formation == f
                    FilterChip(
                        selected = isSelected,
                        onClick = { gameStateManager.setFormation(f) },
                        label = {
                            Text(
                                text = f.label,
                                fontWeight = if (isSelected) FontWeight.Black else FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = ElectricCyan,
                            selectedLabelColor = Color.Black,
                            containerColor = StadiumCardBg,
                            labelColor = Color.White
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Pitch Formation Visual
            ThaiPitchView(
                starters = starters,
                formation = club.tactics.formation,
                ballX = 50f,
                ballY = 50f,
                possessionHome = true,
                activePlayerName = starters.firstOrNull()?.name ?: "",
                homeTeamColor = club.kit.primaryColor,
                awayTeamColor = 0xFF546E7A
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Starting 7 List (Tap to Swap or View Detail)
            Text(
                text = "⚽ 7 ผู้เล่นตัวจริงในสนาม (แตะเพื่อสลับตัวสำรอง)",
                color = TournamentGold,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(6.dp))
        }

        // Starting 7 Items
        items(starters) { player ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 3.dp)
                    .clickable {
                        selectedPlayerToSwap = player
                    },
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (selectedPlayerToSwap?.id == player.id) Color(0xFF1E3A5F) else StadiumCardBg
                ),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (selectedPlayerToSwap?.id == player.id) ElectricCyan else StadiumCardBorder
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        // Position badge
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF263238)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = player.position.shortName,
                                color = ElectricCyan,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Black
                            )
                        }

                        Spacer(modifier = Modifier.width(10.dp))

                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "#${player.number} ${player.name}",
                                    color = Color.White,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                if (club.tactics.captainId == player.id) {
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "(C)",
                                        color = TournamentGold,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                }
                            }
                            Text(
                                text = "${player.nickname} • ท่าไม้ตาย: ${player.signatureSkill}",
                                color = TextSecondary,
                                fontSize = 11.sp
                            )
                        }
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "${player.ovr}",
                            color = TournamentGold,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Black
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Icon(
                            imageVector = Icons.Default.SwapVert,
                            contentDescription = "Swap",
                            tint = ElectricCyan,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(14.dp))

            // Bench Players List
            Text(
                text = "💺 ม้านั่งสำรอง (Bench)",
                color = Color(0xFFB0BEC5),
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(6.dp))
        }

        items(bench) { player ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 3.dp)
                    .clickable {
                        if (selectedPlayerToSwap != null) {
                            gameStateManager.swapPlayers(selectedPlayerToSwap!!.id, player.id)
                            selectedPlayerToSwap = null
                        } else {
                            selectedPlayerDetail = player
                        }
                    },
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E293B))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(30.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF1E293B)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = player.position.shortName,
                                color = Color.Gray,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "#${player.number} ${player.name}",
                                color = Color(0xFFCFD8DC),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium
                            )
                            Text(
                                text = player.nickname,
                                color = TextMuted,
                                fontSize = 11.sp
                            )
                        }
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "${player.ovr}",
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                        if (selectedPlayerToSwap != null) {
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "แตะเพื่อสลับตัว",
                                color = NeonLime,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(16.dp))

            // Play Style Section
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = StadiumCardBg),
                border = androidx.compose.foundation.BorderStroke(1.dp, StadiumCardBorder)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "🎯 สไตล์การเล่นของทีม (Tactical Play Style)",
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    PlayStyle.values().forEach { style ->
                        val isSelected = club.tactics.playStyle == style
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) Color(0xFF1E3A5F) else Color(0xFF0F172A))
                                .clickable { gameStateManager.setPlayStyle(style) }
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(
                                    text = style.thName,
                                    color = if (isSelected) ElectricCyan else Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                                Text(
                                    text = style.boostDesc,
                                    color = TextSecondary,
                                    fontSize = 11.sp
                                )
                            }
                            if (isSelected) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = "Selected",
                                    tint = ElectricCyan
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Tactical Sliders
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = StadiumCardBg),
                border = androidx.compose.foundation.BorderStroke(1.dp, StadiumCardBorder)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "⚙️ ปรับความละเอียดแท็กติก",
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Tempo
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("ความเร็วเกม (Tempo)", color = TextSecondary, fontSize = 12.sp)
                        Text("${tempo.toInt()}%", color = ElectricCyan, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Slider(
                        value = tempo,
                        onValueChange = {
                            tempo = it
                            gameStateManager.updateTacticsSliders(tempo.toInt(), press.toInt(), width.toInt())
                        },
                        valueRange = 20f..100f,
                        colors = SliderDefaults.colors(thumbColor = ElectricCyan, activeTrackColor = ElectricCyan)
                    )

                    // Pressing Intensity
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("การเพรสซิ่งแย่งบอล (Pressing)", color = TextSecondary, fontSize = 12.sp)
                        Text("${press.toInt()}%", color = NeonLime, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Slider(
                        value = press,
                        onValueChange = {
                            press = it
                            gameStateManager.updateTacticsSliders(tempo.toInt(), press.toInt(), width.toInt())
                        },
                        valueRange = 20f..100f,
                        colors = SliderDefaults.colors(thumbColor = NeonLime, activeTrackColor = NeonLime)
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}
