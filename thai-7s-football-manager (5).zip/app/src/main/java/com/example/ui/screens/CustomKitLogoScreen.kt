package com.example.ui.screens

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.GameStateManager
import com.example.model.*
import com.example.ui.components.ClubLogoView
import com.example.ui.components.JerseyView
import com.example.ui.theme.*

@Composable
fun CustomKitLogoScreen(
    gameStateManager: GameStateManager,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val club = gameStateManager.club

    var selectedMode by remember { mutableIntStateOf(0) } // 0 = Kit, 1 = Logo

    // Photo Picker launcher for Custom Jersey Graphic
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            gameStateManager.setUploadedKitImage(uri.toString())
            Toast.makeText(context, "อัปโหลดชุดแข่งสำเร็จ!", Toast.LENGTH_SHORT).show()
        }
    }

    val colorPalette = listOf(
        0xFF0D47A1, // Deep Blue
        0xFFB71C1C, // Crimson Red
        0xFF1B5E20, // Forest Green
        0xFFFFD600, // Golden Yellow
        0xFF00E5FF, // Electric Cyan
        0xFF4A148C, // Royal Purple
        0xFF212121, // Pitch Black
        0xFFFFFFFF, // Pure White
        0xFFFF6D00  // Neon Orange
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(StadiumDarkBg)
            .padding(14.dp)
    ) {
        // Mode Switcher (Kit vs Logo)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = { selectedMode = 0 },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (selectedMode == 0) ElectricCyan else Color(0xFF1E293B)
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .weight(1f)
                    .testTag("kit_tab_button")
            ) {
                Text(
                    text = "👕 ปรับแต่งชุดแข่งประจำทีม",
                    color = if (selectedMode == 0) Color.Black else Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
            }

            Button(
                onClick = { selectedMode = 1 },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (selectedMode == 1) TournamentGold else Color(0xFF1E293B)
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .weight(1f)
                    .testTag("logo_tab_button")
            ) {
                Text(
                    text = "🛡️ ออกแบบโลโก้สโมสร",
                    color = if (selectedMode == 1) Color.Black else Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        if (selectedMode == 0) {
            // JERSEY CUSTOMIZER
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    // Live Jersey Card Display
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = StadiumCardBg),
                        border = androidx.compose.foundation.BorderStroke(1.dp, StadiumCardBorder)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "ตัวอย่างชุดแข่งทีมเหย้า (Home Kit Preview)",
                                color = TextSecondary,
                                fontSize = 12.sp
                            )
                            Spacer(modifier = Modifier.height(10.dp))

                            JerseyView(
                                config = club.kit,
                                size = 140.dp,
                                playerNumber = 10,
                                playerName = "THAILAND 7s"
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            // Upload Photo Kit Button
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Button(
                                    onClick = {
                                        photoPickerLauncher.launch(
                                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                        )
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = NeonLime),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.testTag("upload_kit_button")
                                ) {
                                    Icon(Icons.Default.PhotoCamera, contentDescription = "Upload", tint = Color.Black)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("อัปโหลดรูปภาพชุดแข่งจากเครื่อง", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                }
                            }

                            if (!club.kit.customImageUri.isNullOrEmpty()) {
                                Spacer(modifier = Modifier.height(6.dp))
                                TextButton(
                                    onClick = { gameStateManager.setUploadedKitImage(null) }
                                ) {
                                    Text("✕ ลบรูปที่อัปโหลด กลับมาใช้ลายกราฟิก", color = NeonCoral, fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }

                item {
                    // Pattern Selector
                    Text(
                        text = "🎨 เลือกลวดลายเสื้อแข่ง (Kit Pattern)",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(KitPattern.values()) { pattern ->
                            val isSelected = club.kit.pattern == pattern
                            FilterChip(
                                selected = isSelected,
                                onClick = {
                                    gameStateManager.updateKitConfig(
                                        pattern = pattern,
                                        primary = club.kit.primaryColor,
                                        secondary = club.kit.secondaryColor,
                                        accent = club.kit.accentColor,
                                        numberColor = club.kit.numberColor
                                    )
                                },
                                label = { Text(pattern.label, fontSize = 12.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = ElectricCyan,
                                    selectedLabelColor = Color.Black,
                                    containerColor = StadiumCardBg,
                                    labelColor = Color.White
                                )
                            )
                        }
                    }
                }

                item {
                    // Primary Color
                    Text(
                        text = "🔵 สีหลักของเสื้อ (Primary Color)",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    ColorPickerRow(
                        colors = colorPalette,
                        selectedColor = club.kit.primaryColor,
                        onSelect = { c ->
                            gameStateManager.updateKitConfig(
                                pattern = club.kit.pattern,
                                primary = c,
                                secondary = club.kit.secondaryColor,
                                accent = club.kit.accentColor,
                                numberColor = club.kit.numberColor
                            )
                        }
                    )
                }

                item {
                    // Secondary Color
                    Text(
                        text = "🟡 สีรองของลวดลาย (Secondary Color)",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    ColorPickerRow(
                        colors = colorPalette,
                        selectedColor = club.kit.secondaryColor,
                        onSelect = { c ->
                            gameStateManager.updateKitConfig(
                                pattern = club.kit.pattern,
                                primary = club.kit.primaryColor,
                                secondary = c,
                                accent = club.kit.accentColor,
                                numberColor = club.kit.numberColor
                            )
                        }
                    )
                }

                item {
                    // Number Color
                    Text(
                        text = "⚪ สีหมายเลขเสื้อ (Number Color)",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    ColorPickerRow(
                        colors = listOf(0xFFFFFFFF, 0xFFFFD600, 0xFF00E5FF, 0xFF000000, 0xFFFF3D57),
                        selectedColor = club.kit.numberColor,
                        onSelect = { c ->
                            gameStateManager.updateKitConfig(
                                pattern = club.kit.pattern,
                                primary = club.kit.primaryColor,
                                secondary = club.kit.secondaryColor,
                                accent = club.kit.accentColor,
                                numberColor = c
                            )
                        }
                    )
                }

                item {
                    Spacer(modifier = Modifier.height(16.dp))
                }
            }
        } else {
            // LOGO CUSTOMIZER
            var clubNameText by remember { mutableStateOf(club.name) }
            var shortNameText by remember { mutableStateOf(club.logo.shortName) }

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = StadiumCardBg),
                        border = androidx.compose.foundation.BorderStroke(1.dp, StadiumCardBorder)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "ตัวอย่างโลโก้สโมสร (Club Crest Preview)",
                                color = TextSecondary,
                                fontSize = 12.sp
                            )
                            Spacer(modifier = Modifier.height(10.dp))

                            ClubLogoView(config = club.logo, size = 110.dp)

                            Spacer(modifier = Modifier.height(14.dp))

                            // Club Name Input
                            OutlinedTextField(
                                value = clubNameText,
                                onValueChange = {
                                    clubNameText = it
                                    gameStateManager.updateClubName(it)
                                },
                                label = { Text("ชื่อสโมสรฟุตบอล") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            // Short Name Input
                            OutlinedTextField(
                                value = shortNameText,
                                onValueChange = {
                                    if (it.length <= 4) {
                                        shortNameText = it.uppercase()
                                        gameStateManager.updateLogoConfig(
                                            shape = club.logo.shape,
                                            emblem = club.logo.emblem,
                                            primary = club.logo.primaryColor,
                                            accent = club.logo.accentColor,
                                            shortName = shortNameText
                                        )
                                    }
                                },
                                label = { Text("ตัวย่อชื่อทีม (3-4 ตัวอักษร เช่น SIA, TH7)") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }

                item {
                    // Crest Shape
                    Text(
                        text = "🛡️ รูปทรงโล่ตราสโมสร (Shield Shape)",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(LogoShape.values()) { shape ->
                            val isSelected = club.logo.shape == shape
                            FilterChip(
                                selected = isSelected,
                                onClick = {
                                    gameStateManager.updateLogoConfig(
                                        shape = shape,
                                        emblem = club.logo.emblem,
                                        primary = club.logo.primaryColor,
                                        accent = club.logo.accentColor,
                                        shortName = club.logo.shortName
                                    )
                                },
                                label = { Text(shape.label, fontSize = 12.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = TournamentGold,
                                    selectedLabelColor = Color.Black,
                                    containerColor = StadiumCardBg,
                                    labelColor = Color.White
                                )
                            )
                        }
                    }
                }

                item {
                    // Emblem
                    Text(
                        text = "🐯 ตราสัญลักษณ์มิ่งขวัญ (Mascot Emblem)",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(LogoEmblem.values()) { emblem ->
                            val isSelected = club.logo.emblem == emblem
                            FilterChip(
                                selected = isSelected,
                                onClick = {
                                    gameStateManager.updateLogoConfig(
                                        shape = club.logo.shape,
                                        emblem = emblem,
                                        primary = club.logo.primaryColor,
                                        accent = club.logo.accentColor,
                                        shortName = club.logo.shortName
                                    )
                                },
                                label = { Text(emblem.label, fontSize = 12.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = TournamentGold,
                                    selectedLabelColor = Color.Black,
                                    containerColor = StadiumCardBg,
                                    labelColor = Color.White
                                )
                            )
                        }
                    }
                }

                item {
                    // Logo Accent Color
                    Text(
                        text = "✨ สีขอบและลวดลายตราสโมสร",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    ColorPickerRow(
                        colors = listOf(0xFFFFD600, 0xFF00E5FF, 0xFF00E676, 0xFFFF3D57, 0xFFFFFFFF),
                        selectedColor = club.logo.accentColor,
                        onSelect = { c ->
                            gameStateManager.updateLogoConfig(
                                shape = club.logo.shape,
                                emblem = club.logo.emblem,
                                primary = club.logo.primaryColor,
                                accent = c,
                                shortName = club.logo.shortName
                            )
                        }
                    )
                }

                item {
                    Spacer(modifier = Modifier.height(20.dp))
                }
            }
        }
    }
}

@Composable
private fun ColorPickerRow(
    colors: List<Long>,
    selectedColor: Long,
    onSelect: (Long) -> Unit
) {
    LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        items(colors) { colorLong ->
            val color = Color(colorLong)
            val isSelected = selectedColor == colorLong
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(color)
                    .border(
                        width = if (isSelected) 3.dp else 1.dp,
                        color = if (isSelected) Color.White else Color(0x66FFFFFF),
                        shape = CircleShape
                    )
                    .clickable { onSelect(colorLong) },
                contentAlignment = Alignment.Center
            ) {
                if (isSelected) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = "Selected",
                        tint = if (colorLong == 0xFFFFFFFFL || colorLong == 0xFFFFD600L || colorLong == 0xFF00E5FFL) Color.Black else Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}
