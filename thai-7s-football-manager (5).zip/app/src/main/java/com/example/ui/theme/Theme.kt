package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val StadiumColorScheme = darkColorScheme(
    primary = ElectricCyan,
    onPrimary = Color(0xFF001F2A),
    primaryContainer = Color(0xFF004D61),
    onPrimaryContainer = ElectricCyan,
    secondary = NeonLime,
    onSecondary = Color(0xFF003914),
    secondaryContainer = Color(0xFF005322),
    onSecondaryContainer = NeonLime,
    tertiary = TournamentGold,
    onTertiary = Color(0xFF402D00),
    tertiaryContainer = Color(0xFF5C4300),
    onTertiaryContainer = TournamentGold,
    background = StadiumDarkBg,
    onBackground = TextPrimary,
    surface = StadiumCardBg,
    onSurface = TextPrimary,
    surfaceVariant = StadiumCardBorder,
    onSurfaceVariant = TextSecondary,
    error = NeonCoral,
    onError = Color.White
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = StadiumColorScheme,
        typography = Typography,
        content = content
    )
}
