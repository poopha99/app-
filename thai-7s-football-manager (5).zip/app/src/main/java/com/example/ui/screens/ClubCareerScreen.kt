package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.GameStateManager
import com.example.model.Player
import com.example.model.StadiumTier
import com.example.ui.components.ClubLogoView
import com.example.ui.components.PlayerCardView
import com.example.ui.theme.*
import java.text.NumberFormat
import java.util.Locale

@Composable
fun ClubCareerScreen(
    gameStateManager: GameStateManager,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val club = gameStateManager.club
    val squad = gameStateManager.squad
    val transferMarket = gameStateManager.transferMarket

    var selectedTab by remember { mutableIntStateOf(0) }
    val tabTitles = listOf("🏟️ สเตเดียม", "👥 แฟนคลับ", "🏋️‍♂️ ฝึกซ้อม", "💰 ซื้อขาย")

    val thaiFormat = NumberFormat.getNumberInstance(Locale("th", "TH"))

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(StadiumDarkBg)
            .padding(14.dp)
    ) {
        // Club Finances & Header Bar
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = StadiumCardBg),
            border = androidx.compose.foundation.BorderStroke(1.5.dp, StadiumCardBorder)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    ClubLogoView(config = club.logo, size = 42.dp)
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = club.name,
                            color = Color.White,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Black
                        )
                        Text(
                            text = "${club.stadiumTier.title} • ความจุ ${thaiFormat.format(club.stadiumTier.capacity)} ที่นั่ง",
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                    }
                }

                // Budget Display
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "งบประมาณสโมสร",
                        color = TextSecondary,
                        fontSize = 10.sp
                    )
                    Text(
                        text = "฿${thaiFormat.format(club.budget)}",
                        color = TournamentGold,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Sub Tabs
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = Color(0xFF0F172A),
            contentColor = ElectricCyan,
            divider = {}
        ) {
            tabTitles.forEachIndexed { index, title ->
                Tab(
                    selected = selectedTab == index,
                    onClick = { selectedTab = index },
                    text = {
                        Text(
                            text = title,
                            fontSize = 12.sp,
                            fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal,
                            color = if (selectedTab == index) ElectricCyan else TextSecondary
                        )
                    }
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Content by Tab
        when (selectedTab) {
            0 -> StadiumTab(gameStateManager)
            1 -> FanbaseTab(gameStateManager)
            2 -> TrainingTab(gameStateManager)
            3 -> TransferTab(gameStateManager)
        }
    }
}

@Composable
private fun StadiumTab(gameStateManager: GameStateManager) {
    val club = gameStateManager.club
    val context = LocalContext.current
    val thaiFormat = NumberFormat.getNumberInstance(Locale("th", "TH"))

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            // Current Stadium Overview Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = StadiumCardBg),
                border = androidx.compose.foundation.BorderStroke(1.dp, StadiumCardBorder)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = club.stadiumTier.title,
                                color = TournamentGold,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = club.stadiumTier.description,
                                color = TextSecondary,
                                fontSize = 12.sp
                            )
                        }

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF1B2838))
                                .padding(8.dp)
                        ) {
                            Text("🏟️", fontSize = 24.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("ความจุที่นั่ง", color = TextSecondary, fontSize = 11.sp)
                            Text("${thaiFormat.format(club.stadiumTier.capacity)}", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("ราคาบัตรเข้าชม", color = TextSecondary, fontSize = 11.sp)
                            Text("฿${club.stadiumTier.ticketPrice} / แมตช์", color = NeonLime, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("รายได้ตั๋วสูงสุด", color = TextSecondary, fontSize = 11.sp)
                            Text("฿${thaiFormat.format((club.stadiumTier.capacity * club.stadiumTier.ticketPrice))}", color = TournamentGold, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Upgrade Button
                    val nextTier = when (club.stadiumTier) {
                        StadiumTier.GRASSROOTS -> StadiumTier.FLOODLIGHT_ARENA
                        StadiumTier.FLOODLIGHT_ARENA -> StadiumTier.COVERED_STADIUM
                        StadiumTier.COVERED_STADIUM -> StadiumTier.GRAND_NATIONAL
                        StadiumTier.GRAND_NATIONAL -> null
                    }

                    if (nextTier != null) {
                        Button(
                            onClick = {
                                val success = gameStateManager.upgradeStadium()
                                if (success) {
                                    Toast.makeText(context, "อัปเกรดสนามสำเร็จเป็น ${nextTier.title}!", Toast.LENGTH_SHORT).show()
                                } else {
                                    Toast.makeText(context, "งบประมาณไม่เพียงพอ ต้องการ ฿${thaiFormat.format(nextTier.upgradeCost)}", Toast.LENGTH_SHORT).show()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = NeonLime),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("upgrade_stadium_button")
                        ) {
                            Text(
                                text = "⬆️ อัปเกรดสู่ ${nextTier.title} (฿${thaiFormat.format(nextTier.upgradeCost)})",
                                color = Color.Black,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                    } else {
                        Text(
                            text = "⭐ สเตเดียมระดับสูงสุดแล้ว (Grand National)",
                            color = TournamentGold,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }

        item {
            Text(
                text = "💡 สิ่งอำนวยความสะดวก & ระบบภายในสเตเดียม",
                color = ElectricCyan,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
            )
        }

        // Facilities Items
        items(club.facilities) { fac ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF131C2E)),
                border = androidx.compose.foundation.BorderStroke(1.dp, if (fac.isOwned) NeonLime.copy(alpha = 0.5f) else StadiumCardBorder)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = fac.name,
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                            if (fac.isOwned) {
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "✓ ติดตั้งแล้ว",
                                    color = NeonLime,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                        Text(
                            text = fac.bonusDescription,
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                    }

                    if (!fac.isOwned) {
                        Button(
                            onClick = {
                                val ok = gameStateManager.purchaseFacility(fac.id)
                                if (ok) {
                                    Toast.makeText(context, "ติดตั้ง ${fac.name} สำเร็จ!", Toast.LENGTH_SHORT).show()
                                } else {
                                    Toast.makeText(context, "งบประมาณไม่พอ", Toast.LENGTH_SHORT).show()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = ElectricCyan),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = "฿${thaiFormat.format(fac.cost)}",
                                color = Color.Black,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun FanbaseTab(gameStateManager: GameStateManager) {
    val club = gameStateManager.club
    val context = LocalContext.current
    val thaiFormat = NumberFormat.getNumberInstance(Locale("th", "TH"))

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            // Fan Stats Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = StadiumCardBg),
                border = androidx.compose.foundation.BorderStroke(1.dp, StadiumCardBorder)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "👥 สถิติฐานแฟนคลับสโมสร",
                        color = TournamentGold,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("จำนวนแฟนบอล", color = TextSecondary, fontSize = 11.sp)
                            Text("${thaiFormat.format(club.fanbase.fanCount)} คน", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("ดาวความภักดี", color = TextSecondary, fontSize = 11.sp)
                            Text("⭐".repeat(club.fanbase.loyaltyLevel), fontSize = 13.sp)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("รายได้ของที่ระลึก", color = TextSecondary, fontSize = 11.sp)
                            Text("฿${thaiFormat.format(club.fanbase.merchandiseRevenueRate)} / สัปดาห์", color = NeonLime, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        item {
            Text(
                text = "📣 แคมเปญขยายฐานแฟนคลับ & ประชาสัมพันธ์",
                color = ElectricCyan,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
            )
        }

        // Campaign Actions
        item {
            CampaignCard(
                title = "🤝 จัดงาน Meet & Greet พบปะนักเตะเดินสาย",
                desc = "เปิดโอกาสให้แฟนบอลถ่ายรูปและขอลายเซ็น เพิ่มแฟนคลับ +1,200 คน",
                cost = 100_000,
                onLaunch = {
                    val ok = gameStateManager.launchFanCampaign("MEET_AND_GREET")
                    Toast.makeText(context, if (ok) "จัดงานสำเร็จ! แฟนคลับเพิ่มขึ้น" else "งบประมาณไม่พอ", Toast.LENGTH_SHORT).show()
                }
            )
        }

        item {
            CampaignCard(
                title = "📱 ยิงแอดไฮไลท์แมตช์ 7 คนลงโซเชียล",
                desc = "ปล่อยคลิปประตูสวยๆ และช็อตพากย์มันส์ลง TikTok & Facebook เพิ่มแฟนคลับ +3,500 คน",
                cost = 250_000,
                onLaunch = {
                    val ok = gameStateManager.launchFanCampaign("SOCIAL_ADS")
                    Toast.makeText(context, if (ok) "ยิงแอดสำเร็จ! แฟนคลับพุ่งทะยาน" else "งบประมาณไม่พอ", Toast.LENGTH_SHORT).show()
                }
            )
        }

        item {
            CampaignCard(
                title = "👕 จัดแคมเปญแจกเสื้อแข่งลิขสิทธิ์สโมสร",
                desc = "แจกเสื้อแข่งประจำทีมรุ่นใหม่ล่าสุด เพิ่มความภักดี +1 ดาว และแฟนคลับ +5,800 คน",
                cost = 400_000,
                onLaunch = {
                    val ok = gameStateManager.launchFanCampaign("JERSEY_GIVEAWAY")
                    Toast.makeText(context, if (ok) "แจกเสื้อสำเร็จ! แฟนคลับหลงรักสโมสร" else "งบประมาณไม่พอ", Toast.LENGTH_SHORT).show()
                }
            )
        }
    }
}

@Composable
private fun CampaignCard(title: String, desc: String, cost: Long, onLaunch: () -> Unit) {
    val thaiFormat = NumberFormat.getNumberInstance(Locale("th", "TH"))
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = StadiumCardBg),
        border = androidx.compose.foundation.BorderStroke(1.dp, StadiumCardBorder)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(text = title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = desc, color = TextSecondary, fontSize = 11.sp)
            Spacer(modifier = Modifier.height(8.dp))
            Button(
                onClick = onLaunch,
                colors = ButtonDefaults.buttonColors(containerColor = ElectricCyan),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(text = "เริ่มแคมเปญ (฿${thaiFormat.format(cost)})", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun TrainingTab(gameStateManager: GameStateManager) {
    val squad = gameStateManager.squad
    val context = LocalContext.current
    var selectedPlayerForTraining by remember { mutableStateOf<Player?>(null) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text(
                text = "🏋️‍♂️ เลือกลักษณะการฝึกซ้อม (Drills) • ค่าฝึก ฿50,000",
                color = ElectricCyan,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
            )
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = {
                        val res = gameStateManager.runTrainingDrill("SHOOTING", selectedPlayerForTraining?.id)
                        Toast.makeText(context, res, Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NeonCoral),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("🎯 ซ้อมยิง", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Text("+Shooting", fontSize = 9.sp)
                    }
                }

                Button(
                    onClick = {
                        val res = gameStateManager.runTrainingDrill("PACE", selectedPlayerForTraining?.id)
                        Toast.makeText(context, res, Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NeonLime),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("⚡ ซ้อมสปีด", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color.Black)
                        Text("+Pace", fontSize = 9.sp, color = Color.Black)
                    }
                }

                Button(
                    onClick = {
                        val res = gameStateManager.runTrainingDrill("PASSING", selectedPlayerForTraining?.id)
                        Toast.makeText(context, res, Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ElectricCyan),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("👟 เคาะสั้น", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color.Black)
                        Text("+Passing", fontSize = 9.sp, color = Color.Black)
                    }
                }

                Button(
                    onClick = {
                        val res = gameStateManager.runTrainingDrill("DEFENDING", selectedPlayerForTraining?.id)
                        Toast.makeText(context, res, Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2979FF)),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("🛡️ เกมรับ", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Text("+Defense", fontSize = 9.sp)
                    }
                }
            }
        }

        item {
            Text(
                text = "เลือกนักเตะที่ต้องการเน้นซ้อมพิเศษ (หรือแตะปุ่มด้านบนเพื่อซ้อมทั้งทีม):",
                color = TextSecondary,
                fontSize = 11.sp
            )
        }

        items(squad) { p ->
            val isSelected = selectedPlayerForTraining?.id == p.id
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        selectedPlayerForTraining = if (isSelected) null else p
                    },
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = if (isSelected) Color(0xFF1E3A5F) else StadiumCardBg),
                border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) ElectricCyan else StadiumCardBorder)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("#${p.number}", color = Color.Gray, fontSize = 12.sp)
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(p.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text("${p.position.shortName} • ${p.nickname}", color = TextSecondary, fontSize = 11.sp)
                        }
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("OVR ${p.ovr}", color = TournamentGold, fontWeight = FontWeight.Black, fontSize = 13.sp)
                        if (isSelected) {
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("✓ เลือกแล้ว", color = NeonLime, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TransferTab(gameStateManager: GameStateManager) {
    val transferMarket = gameStateManager.transferMarket
    val squad = gameStateManager.squad
    val club = gameStateManager.club
    val context = LocalContext.current
    val thaiFormat = NumberFormat.getNumberInstance(Locale("th", "TH"))

    var viewMode by remember { mutableIntStateOf(0) } // 0 = ซื้อนักเตะ, 1 = ขายนักเตะในทีม

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = { viewMode = 0 },
                    colors = ButtonDefaults.buttonColors(containerColor = if (viewMode == 0) ElectricCyan else Color(0xFF1E293B)),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("🛒 ตลาดซื้อนักเตะไทย", color = if (viewMode == 0) Color.Black else Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }

                Button(
                    onClick = { viewMode = 1 },
                    colors = ButtonDefaults.buttonColors(containerColor = if (viewMode == 1) TournamentGold else Color(0xFF1E293B)),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("💸 ขายนัดเตะในทีม", color = if (viewMode == 1) Color.Black else Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        }

        if (viewMode == 0) {
            // Market List
            items(transferMarket) { player ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = StadiumCardBg),
                    border = androidx.compose.foundation.BorderStroke(1.dp, StadiumCardBorder)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(text = player.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text(text = "${player.position.thName} • ${player.nickname}", color = TextSecondary, fontSize = 11.sp)
                            }
                            Text(text = "OVR ${player.ovr}", color = TournamentGold, fontWeight = FontWeight.Black, fontSize = 16.sp)
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Text(text = "🌟 สกิล: ${player.signatureSkill}", color = ElectricCyan, fontSize = 11.sp)
                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = "ค่าตัว: ฿${thaiFormat.format(player.marketValue)}", color = NeonLime, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Button(
                                onClick = {
                                    val ok = gameStateManager.buyPlayer(player)
                                    if (ok) {
                                        Toast.makeText(context, "เซ็นสัญญา ${player.name} เข้าสู่ทีมสำเร็จ!", Toast.LENGTH_SHORT).show()
                                    } else {
                                        Toast.makeText(context, "งบประมาณสโมสรไม่เพียงพอ", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = NeonLime),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("เซ็นสัญญา", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        } else {
            // Sell Squad Players
            items(squad) { player ->
                if (!player.isCustom) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = StadiumCardBg),
                        border = androidx.compose.foundation.BorderStroke(1.dp, StadiumCardBorder)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(text = player.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text(text = "ค่าตัวประเมิน: ฿${thaiFormat.format(player.marketValue)}", color = TournamentGold, fontSize = 11.sp)
                            }

                            Button(
                                onClick = {
                                    val ok = gameStateManager.sellPlayer(player.id)
                                    if (ok) {
                                        Toast.makeText(context, "ปล่อยตัว ${player.name} และรับเงินค่าตัวเข้าคลังสโมสร!", Toast.LENGTH_SHORT).show()
                                    } else {
                                        Toast.makeText(context, "ไม่สามารถขายได้ (ต้องเหลือนักเตะในทีมอย่างน้อย 8 คน)", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = NeonCoral),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("ปล่อยตัวขาย", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}
