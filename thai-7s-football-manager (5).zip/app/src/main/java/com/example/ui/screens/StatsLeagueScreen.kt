package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.GameStateManager
import com.example.model.Player
import com.example.ui.components.ClubLogoView
import com.example.ui.theme.*

@Composable
fun StatsLeagueScreen(
    gameStateManager: GameStateManager,
    modifier: Modifier = Modifier
) {
    val squad = gameStateManager.squad
    val leagueTable = gameStateManager.leagueTable
    val topScorers = gameStateManager.topScorers
    val club = gameStateManager.club

    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = listOf("📊 สถิติผู้เล่นรายคน", "🏆 ตารางคะแนนลีก", "👟 ดาวซัลโว")

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(StadiumDarkBg)
            .padding(14.dp)
    ) {
        // Tab Selector
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = Color(0xFF0F172A),
            contentColor = ElectricCyan,
            divider = {}
        ) {
            tabs.forEachIndexed { index, title ->
                Tab(
                    selected = selectedTab == index,
                    onClick = { selectedTab = index },
                    text = {
                        Text(
                            text = title,
                            fontSize = 12.sp,
                            fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal,
                            color = if (selectedTab == index) ElectricCyan else TextSecondary
                        )
                    }
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        when (selectedTab) {
            0 -> PlayerStatsTab(squad)
            1 -> LeagueTableTab(leagueTable, club.name)
            2 -> TopScorersTab(topScorers)
        }
    }
}

@Composable
private fun PlayerStatsTab(squad: List<Player>) {
    var sortMode by remember { mutableIntStateOf(0) } // 0 = Goals, 1 = Assists, 2 = Rating, 3 = Matches

    val sortedSquad = remember(squad, sortMode) {
        when (sortMode) {
            0 -> squad.sortedByDescending { it.stats.goals }
            1 -> squad.sortedByDescending { it.stats.assists }
            2 -> squad.sortedByDescending { it.stats.averageRating }
            else -> squad.sortedByDescending { it.stats.matchesPlayed }
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            // Sort Filter Chips
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("เรียงตาม:", color = TextSecondary, fontSize = 11.sp)
                FilterChip(
                    selected = sortMode == 0,
                    onClick = { sortMode = 0 },
                    label = { Text("ประตู (Goals)", fontSize = 11.sp) },
                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = TournamentGold, selectedLabelColor = Color.Black)
                )
                FilterChip(
                    selected = sortMode == 1,
                    onClick = { sortMode = 1 },
                    label = { Text("แอสซิสต์", fontSize = 11.sp) },
                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = ElectricCyan, selectedLabelColor = Color.Black)
                )
                FilterChip(
                    selected = sortMode == 2,
                    onClick = { sortMode = 2 },
                    label = { Text("เรตติ้ง", fontSize = 11.sp) },
                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = NeonLime, selectedLabelColor = Color.Black)
                )
            }
        }

        items(sortedSquad) { player ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = StadiumCardBg),
                border = androidx.compose.foundation.BorderStroke(1.dp, StadiumCardBorder)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(34.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF1E293B)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = player.position.shortName,
                                    color = ElectricCyan,
                                    fontWeight = FontWeight.Black,
                                    fontSize = 11.sp
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "#${player.number} ${player.name}",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                                Text(
                                    text = "\"${player.nickname}\"",
                                    color = TournamentGold,
                                    fontSize = 11.sp
                                )
                            }
                        }

                        // Average Rating Badge
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(Color(0xFF0F172A))
                                .border(1.dp, NeonLime, RoundedCornerShape(6.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "★ ${String.format("%.1f", player.stats.averageRating)}",
                                color = NeonLime,
                                fontWeight = FontWeight.Black,
                                fontSize = 12.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Stats Grid Row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFF0B101D), RoundedCornerShape(8.dp))
                            .padding(vertical = 6.dp, horizontal = 10.dp),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        StatMetric("ลงเล่น", "${player.stats.matchesPlayed}")
                        StatMetric("ประตู", "${player.stats.goals}", isHighlight = player.stats.goals > 0)
                        StatMetric("แอสซิสต์", "${player.stats.assists}", isHighlight = player.stats.assists > 0)
                        StatMetric("คลีนชีต", "${player.stats.cleanSheets}")
                        StatMetric("แย่งบอล", "${player.stats.tacklesWon}")
                    }
                }
            }
        }
    }
}

@Composable
private fun StatMetric(label: String, value: String, isHighlight: Boolean = false) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = label, color = TextSecondary, fontSize = 10.sp)
        Text(
            text = value,
            color = if (isHighlight) TournamentGold else Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = 13.sp
        )
    }
}

@Composable
private fun LeagueTableTab(leagueTable: List<com.example.model.LeagueTeamRow>, userTeamName: String) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        item {
            // Header Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF1E293B), RoundedCornerShape(8.dp))
                    .padding(horizontal = 10.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("#", color = TextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(22.dp))
                Text("สโมสร (Club)", color = TextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Text("แข่ง", color = TextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(30.dp))
                Text("ชนะ", color = TextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(30.dp))
                Text("เสมอ", color = TextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(30.dp))
                Text("แพ้", color = TextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(30.dp))
                Text("ได้/เสีย", color = TextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(42.dp))
                Text("แต้ม", color = TournamentGold, fontSize = 11.sp, fontWeight = FontWeight.Black, modifier = Modifier.width(34.dp))
            }
        }

        items(leagueTable) { row ->
            val isUser = row.isUserTeam
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (isUser) Color(0xFF153356) else StadiumCardBg)
                    .border(
                        1.dp,
                        if (isUser) ElectricCyan else Color.Transparent,
                        RoundedCornerShape(8.dp)
                    )
                    .padding(horizontal = 10.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${row.rank}",
                    color = if (row.rank == 1) TournamentGold else Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    modifier = Modifier.width(22.dp)
                )

                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Box(
                        modifier = Modifier
                            .size(20.dp)
                            .clip(CircleShape)
                            .background(Color(row.badgeColor)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(row.shortName.take(2), color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = row.teamName,
                        color = if (isUser) ElectricCyan else Color.White,
                        fontWeight = if (isUser) FontWeight.Black else FontWeight.Medium,
                        fontSize = 12.sp,
                        maxLines = 1
                    )
                }

                Text("${row.played}", color = Color.White, fontSize = 11.sp, modifier = Modifier.width(30.dp))
                Text("${row.won}", color = NeonLime, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(30.dp))
                Text("${row.drawn}", color = TextSecondary, fontSize = 11.sp, modifier = Modifier.width(30.dp))
                Text("${row.lost}", color = NeonCoral, fontSize = 11.sp, modifier = Modifier.width(30.dp))
                Text("${row.goalsFor}:${row.goalsAgainst}", color = TextSecondary, fontSize = 10.sp, modifier = Modifier.width(42.dp))
                Text("${row.points}", color = TournamentGold, fontSize = 13.sp, fontWeight = FontWeight.Black, modifier = Modifier.width(34.dp))
            }
        }
    }
}

@Composable
private fun TopScorersTab(topScorers: List<com.example.model.TopScorerEntry>) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            Text(
                text = "👟 ทำเนียบดาวซัลโวฟุตบอล 7 คนเงินล้าน (Top Scorers)",
                color = TournamentGold,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
            )
        }

        items(topScorers) { entry ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = if (entry.isUserPlayer) Color(0xFF1E3A5F) else StadiumCardBg),
                border = androidx.compose.foundation.BorderStroke(1.dp, if (entry.isUserPlayer) ElectricCyan else StadiumCardBorder)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = if (entry.rank == 1) "🥇" else if (entry.rank == 2) "🥈" else if (entry.rank == 3) "🥉" else "${entry.rank}.",
                            fontSize = 16.sp
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = entry.playerName,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                                if (entry.isUserPlayer) {
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("(ทีมเรา)", color = ElectricCyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                            Text(
                                text = "${entry.teamName} • ลงแข่ง ${entry.matches} นัด",
                                color = TextSecondary,
                                fontSize = 11.sp
                            )
                        }
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "⚽ ${entry.goals} ประตู",
                                color = TournamentGold,
                                fontWeight = FontWeight.Black,
                                fontSize = 14.sp
                            )
                            Text(
                                text = "${entry.assists} แอสซิสต์",
                                color = ElectricCyan,
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            }
        }
    }
}
