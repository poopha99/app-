package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.GameStateManager
import com.example.ui.components.ClubLogoView
import com.example.ui.theme.*
import java.text.NumberFormat
import java.util.Locale

enum class AppTab(val title: String, val icon: ImageVector, val tag: String) {
    MATCH("แข่งขัน", Icons.Default.SportsSoccer, "tab_match"),
    TACTICS("แผน 7 คน", Icons.Default.FormatListNumbered, "tab_tactics"),
    CAREER("สโมสร", Icons.Default.AccountBalance, "tab_career"),
    KIT_LOGO("ชุด & โลโก้", Icons.Default.Checkroom, "tab_kit_logo"),
    CREATE_PLAYER("สร้างนักเตะ", Icons.Default.PersonAdd, "tab_create_player"),
    STATS("สถิติลีก", Icons.Default.Leaderboard, "tab_stats")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppScreen(
    gameStateManager: GameStateManager,
    modifier: Modifier = Modifier
) {
    var currentTab by remember { mutableStateOf(AppTab.MATCH) }
    val club = gameStateManager.club
    val thaiFormat = NumberFormat.getNumberInstance(Locale("th", "TH"))

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        ClubLogoView(config = club.logo, size = 32.dp)
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = club.name,
                                color = Color.White,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Black,
                                maxLines = 1
                            )
                            Text(
                                text = "🇹🇭 Thai 7s Football Manager",
                                color = ElectricCyan,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                },
                actions = {
                    // Quick Budget & Fan Badge
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .padding(end = 12.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF131C2E))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "฿${thaiFormat.format(club.budget)}",
                            color = TournamentGold,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = StadiumCardBg,
                    titleContentColor = Color.White
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = Color(0xFF090E18),
                contentColor = ElectricCyan,
                tonalElevation = 8.dp
            ) {
                AppTab.values().forEach { tab ->
                    val isSelected = currentTab == tab
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { currentTab = tab },
                        icon = {
                            Icon(
                                imageVector = tab.icon,
                                contentDescription = tab.title,
                                tint = if (isSelected) ElectricCyan else TextSecondary
                            )
                        },
                        label = {
                            Text(
                                text = tab.title,
                                fontSize = 9.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) ElectricCyan else TextSecondary,
                                maxLines = 1
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = ElectricCyan,
                            unselectedIconColor = TextSecondary,
                            indicatorColor = Color(0xFF132238)
                        ),
                        modifier = Modifier.testTag(tab.tag)
                    )
                }
            }
        },
        containerColor = StadiumDarkBg
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentTab) {
                AppTab.MATCH -> MatchDayScreen(gameStateManager = gameStateManager)
                AppTab.TACTICS -> TacticsScreen(gameStateManager = gameStateManager)
                AppTab.CAREER -> ClubCareerScreen(gameStateManager = gameStateManager)
                AppTab.KIT_LOGO -> CustomKitLogoScreen(gameStateManager = gameStateManager)
                AppTab.CREATE_PLAYER -> CreatePlayerScreen(gameStateManager = gameStateManager)
                AppTab.STATS -> StatsLeagueScreen(gameStateManager = gameStateManager)
            }
        }
    }
}
