package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.DefaultData
import com.example.data.GameStateManager
import com.example.model.CommentaryType
import com.example.model.MatchOpponent
import com.example.ui.components.ClubLogoView
import com.example.ui.components.ThaiPitchView
import com.example.ui.theme.*

@Composable
fun MatchDayScreen(
    gameStateManager: GameStateManager,
    modifier: Modifier = Modifier
) {
    val matchState by gameStateManager.matchState.collectAsStateWithLifecycle()
    val club = gameStateManager.club
    val starters = gameStateManager.getStarters()

    var showOpponentPicker by remember { mutableStateOf(false) }
    var isMuted by remember { mutableStateOf(gameStateManager.commentarySpeaker.isMuted) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(StadiumDarkBg)
            .padding(14.dp)
    ) {
        // Broadcast Scoreboard (eFootball Style)
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("broadcast_scoreboard"),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = StadiumCardBg),
            border = androidx.compose.foundation.BorderStroke(1.5.dp, StadiumCardBorder)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp)
            ) {
                // League Bar & Match Clock
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(TournamentGold)
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "THAILAND 7s PRO LEAGUE",
                                color = Color.Black,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                    }

                    // Minute & Half Display
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (matchState.isPlaying) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(NeonLime)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                        }
                        Text(
                            text = if (matchState.isFinished) "จบเกม (FT)" else "${matchState.currentMinute}' (ครึ่งที่ ${matchState.half})",
                            color = if (matchState.isFinished) NeonCoral else NeonLime,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Scoreboard Row: Home vs Away
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Home Team (My Club)
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        ClubLogoView(config = club.logo, size = 38.dp)
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = club.name,
                                color = Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1
                            )
                            Text(
                                text = "เจ้าบ้าน (Home)",
                                color = TextSecondary,
                                fontSize = 10.sp
                            )
                        }
                    }

                    // Score Display
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFF070B14))
                            .border(1.dp, Color(0xFF37474F), RoundedCornerShape(10.dp))
                            .padding(horizontal = 14.dp, vertical = 6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "${matchState.homeScore} - ${matchState.awayScore}",
                            color = TournamentGold,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 2.sp
                        )
                    }

                    // Away Team (Opponent)
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.End,
                        modifier = Modifier
                            .weight(1f)
                            .clickable {
                                if (!matchState.isPlaying && !matchState.isFinished) {
                                    showOpponentPicker = true
                                }
                            }
                    ) {
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = matchState.opponent.name,
                                color = Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1
                            )
                            Text(
                                text = "OVR ${matchState.opponent.ovr} ⚡",
                                color = NeonCoral,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(Color(matchState.opponent.badgeColor))
                                .border(1.5.dp, Color.White.copy(alpha = 0.4f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = matchState.opponent.shortName,
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // 2D Tactical Pitch View (7v7)
        ThaiPitchView(
            starters = starters,
            formation = club.tactics.formation,
            ballX = matchState.ballX,
            ballY = matchState.ballY,
            possessionHome = matchState.possessionHome,
            activePlayerName = matchState.activePlayerName,
            homeTeamColor = club.kit.primaryColor,
            awayTeamColor = matchState.opponent.badgeColor
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Live Thai Walkover Commentary Ticker
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF10192A)),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E2D4A))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = {
                        isMuted = !isMuted
                        gameStateManager.commentarySpeaker.isMuted = isMuted
                        if (!isMuted) {
                            gameStateManager.commentarySpeaker.speak("เปิดเสียงพากย์ฟุตบอล 7 คนเดินสายแล้วครับ!")
                        }
                    },
                    modifier = Modifier
                        .size(36.dp)
                        .testTag("toggle_voice_button")
                ) {
                    Icon(
                        imageVector = if (isMuted) Icons.Default.VolumeOff else Icons.Default.VolumeUp,
                        contentDescription = "เสียงพากย์",
                        tint = if (isMuted) Color.Gray else ElectricCyan
                    )
                }

                Spacer(modifier = Modifier.width(6.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "🎙️ นักพากย์บอลเดินสายสด",
                        color = ElectricCyan,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = matchState.latestCommentary?.text
                            ?: "ยินดีต้อนรับสู่สนามฟุตบอล 7 คน! พร้อมเปิดฉากความมันส์แล้วครับท่านผู้ชม",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        maxLines = 2
                    )
                }

                // Voice Test Button
                IconButton(
                    onClick = {
                        gameStateManager.commentarySpeaker.speak(
                            "โอ้โห ดอกนี้งามหยด ยิงไกลยัดเสาแรกสะเทือนไปถึงดวงดาว!",
                            isGoal = true
                        )
                    },
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Campaign,
                        contentDescription = "ทดสอบเสียง",
                        tint = TournamentGold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Interactive In-Match Tactical Control Buttons
        if (matchState.isPlaying) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = { gameStateManager.userTriggerShoot() },
                    colors = ButtonDefaults.buttonColors(containerColor = NeonCoral),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("shoot_button")
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("⚽ สับไกยิง!", fontSize = 12.sp, fontWeight = FontWeight.Black)
                        Text("Shoot", fontSize = 9.sp, color = Color.White.copy(alpha = 0.8f))
                    }
                }

                Button(
                    onClick = { gameStateManager.userTriggerThroughPass() },
                    colors = ButtonDefaults.buttonColors(containerColor = ElectricCyan),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("pass_button")
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("🎯 แทงทะลุช่อง", fontSize = 12.sp, fontWeight = FontWeight.Black, color = Color.Black)
                        Text("Through Pass", fontSize = 9.sp, color = Color.Black.copy(alpha = 0.7f))
                    }
                }

                Button(
                    onClick = { gameStateManager.userTriggerHighPress() },
                    colors = ButtonDefaults.buttonColors(containerColor = NeonLime),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("press_button")
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("⚡ เพรสซิ่ง!", fontSize = 12.sp, fontWeight = FontWeight.Black, color = Color.Black)
                        Text("High Press", fontSize = 9.sp, color = Color.Black.copy(alpha = 0.7f))
                    }
                }
            }
        } else {
            // Match Flow Control Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (matchState.isFinished) {
                    Button(
                        onClick = {
                            showOpponentPicker = true
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = TournamentGold),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("next_match_button")
                    ) {
                        Text(
                            text = "🏆 เลือกลงแข่งแมตช์ต่อไป",
                            color = Color.Black,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                } else if (matchState.currentMinute == 0) {
                    Button(
                        onClick = { gameStateManager.startNewMatch(matchState.opponent) },
                        colors = ButtonDefaults.buttonColors(containerColor = NeonLime),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("kickoff_button")
                    ) {
                        Text(
                            text = "⚽ เป่านกหวีดเริ่มแข่ง 7 คน!",
                            color = Color.Black,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Black
                        )
                    }

                    OutlinedButton(
                        onClick = { showOpponentPicker = true },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.height(48.dp)
                    ) {
                        Icon(Icons.Default.SwapHoriz, contentDescription = "เปลี่ยนทีม")
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("เปลี่ยนคู่แข่ง", color = Color.White)
                    }
                } else {
                    Button(
                        onClick = { gameStateManager.resumeMatch() },
                        colors = ButtonDefaults.buttonColors(containerColor = ElectricCyan),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                    ) {
                        Text("▶️ ลุยต่อครึ่งหลัง", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Match Statistics & Commentary Feed Tabs
        Text(
            text = "📜 บันทึกการแข่งขัน & เสียงพากย์สด",
            color = TextSecondary,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(4.dp))

        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0xFF0B101D))
                .border(1.dp, Color(0xFF1B243B), RoundedCornerShape(12.dp))
                .padding(8.dp)
        ) {
            items(matchState.commentaryHistory) { item ->
                CommentaryRow(item)
            }
        }
    }

    // Opponent Selection Dialog
    if (showOpponentPicker) {
        AlertDialog(
            onDismissRequest = { showOpponentPicker = false },
            title = {
                Text(
                    text = "🏆 เลือกทีมคู่แข่งในลีก 7 คน",
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            },
            text = {
                LazyColumn(modifier = Modifier.fillMaxWidth()) {
                    items(DefaultData.getOpponents()) { opp ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .clickable {
                                    showOpponentPicker = false
                                    gameStateManager.startNewMatch(opp)
                                },
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF182238))
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(34.dp)
                                            .clip(CircleShape)
                                            .background(Color(opp.badgeColor)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = opp.shortName,
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(
                                            text = opp.name,
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp
                                        )
                                        Text(
                                            text = "ดาวเด่น: ${opp.starPlayer} (${opp.city})",
                                            color = TextSecondary,
                                            fontSize = 11.sp
                                        )
                                    }
                                }

                                Text(
                                    text = "OVR ${opp.ovr}",
                                    color = TournamentGold,
                                    fontWeight = FontWeight.Black,
                                    fontSize = 13.sp
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showOpponentPicker = false }) {
                    Text("ปิด", color = ElectricCyan)
                }
            },
            containerColor = StadiumCardBg
        )
    }
}

@Composable
private fun CommentaryRow(item: com.example.model.CommentaryItem) {
    val icon = when (item.type) {
        CommentaryType.GOAL -> "⚽"
        CommentaryType.SAVE -> "🧤"
        CommentaryType.SHOT -> "💥"
        CommentaryType.TACKLE -> "🛡️"
        CommentaryType.WOODWORK -> "⚡"
        CommentaryType.HALFTIME, CommentaryType.FULLTIME -> "⏱️"
        else -> "👟"
    }

    val textColor = when (item.type) {
        CommentaryType.GOAL -> TournamentGold
        CommentaryType.SAVE -> ElectricCyan
        CommentaryType.SHOT -> NeonCoral
        else -> Color(0xFFECEFF1)
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.Top
    ) {
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(4.dp))
                .background(Color(0xFF1E293B))
                .padding(horizontal = 5.dp, vertical = 2.dp)
        ) {
            Text(
                text = "${item.minute}'",
                color = ElectricCyan,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.width(8.dp))
        Text(text = icon, fontSize = 12.sp)
        Spacer(modifier = Modifier.width(6.dp))

        Text(
            text = item.text,
            color = textColor,
            fontSize = 12.sp,
            fontWeight = if (item.type == CommentaryType.GOAL) FontWeight.Black else FontWeight.Normal,
            modifier = Modifier.weight(1f)
        )
    }
}
