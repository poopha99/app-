package com.example.data

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.example.audio.ThaiCommentarySpeaker
import com.example.model.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.roundToInt
import kotlin.random.Random

class GameStateManager(private val context: Context) {

    val commentarySpeaker = ThaiCommentarySpeaker(context)

    // Club State
    var club by mutableStateOf(Club())
        private set

    // Squad State
    var squad by mutableStateOf(DefaultData.getInitialUserSquad())
        private set

    // Active Starting 7 (1 GK + 6 Outfield players)
    var startingSevenIds by mutableStateOf(
        listOf("th_gk_1", "th_df_1", "th_df_2", "th_mf_1", "th_mf_2", "th_mf_3", "th_fw_1")
    )
        private set

    // Transfer Market
    var transferMarket by mutableStateOf(DefaultData.getTransferMarketList())
        private set

    // League Table & Top Scorers
    var leagueTable by mutableStateOf(DefaultData.getInitialLeagueTable(club.name, club.shortName))
        private set

    var topScorers by mutableStateOf(DefaultData.getInitialTopScorers("ธีรศิลป์ แดงดา"))
        private set

    // Custom Player (User can create 1 custom player)
    var customPlayer by mutableStateOf<Player?>(null)
        private set

    // Match State
    private val _matchState = MutableStateFlow(
        LiveMatchState(opponent = DefaultData.getOpponents()[0])
    )
    val matchState: StateFlow<LiveMatchState> = _matchState.asStateFlow()

    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private var matchJob: Job? = null

    init {
        // Set default captain & takers
        club = club.copy(
            tactics = club.tactics.copy(
                captainId = "th_fw_1",
                penaltyTakerId = "th_fw_1",
                freekickTakerId = "th_df_1",
                cornerTakerId = "th_df_1"
            )
        )
    }

    fun getStarters(): List<Player> {
        val currentSquadMap = squad.associateBy { it.id }
        return startingSevenIds.mapNotNull { currentSquadMap[it] }
    }

    fun getBench(): List<Player> {
        val startersSet = startingSevenIds.toSet()
        return squad.filter { it.id !in startersSet }
    }

    // TACTICS & FORMATION
    fun setFormation(formation: FormationType) {
        club = club.copy(tactics = club.tactics.copy(formation = formation))
    }

    fun setPlayStyle(style: PlayStyle) {
        club = club.copy(tactics = club.tactics.copy(playStyle = style))
    }

    fun updateTacticsSliders(tempo: Int, press: Int, width: Int) {
        club = club.copy(
            tactics = club.tactics.copy(
                gameTempo = tempo,
                pressingIntensity = press,
                pitchWidth = width
            )
        )
    }

    fun setCaptain(playerId: String) {
        club = club.copy(tactics = club.tactics.copy(captainId = playerId))
    }

    fun setSetPieceTaker(type: String, playerId: String) {
        club = when (type) {
            "penalty" -> club.copy(tactics = club.tactics.copy(penaltyTakerId = playerId))
            "freekick" -> club.copy(tactics = club.tactics.copy(freekickTakerId = playerId))
            "corner" -> club.copy(tactics = club.tactics.copy(cornerTakerId = playerId))
            else -> club
        }
    }

    fun swapPlayers(starterId: String, benchId: String) {
        val newStarters = startingSevenIds.toMutableList()
        val index = newStarters.indexOf(starterId)
        if (index != -1) {
            newStarters[index] = benchId
            startingSevenIds = newStarters
        }
    }

    // CUSTOM KIT & LOGO
    fun updateKitConfig(
        pattern: KitPattern,
        primary: Long,
        secondary: Long,
        accent: Long,
        numberColor: Long,
        customImageUri: String? = club.kit.customImageUri
    ) {
        club = club.copy(
            kit = club.kit.copy(
                pattern = pattern,
                primaryColor = primary,
                secondaryColor = secondary,
                accentColor = accent,
                numberColor = numberColor,
                customImageUri = customImageUri
            )
        )
    }

    fun setUploadedKitImage(uriString: String?) {
        club = club.copy(
            kit = club.kit.copy(customImageUri = uriString)
        )
    }

    fun updateLogoConfig(
        shape: LogoShape,
        emblem: LogoEmblem,
        primary: Long,
        accent: Long,
        shortName: String
    ) {
        club = club.copy(
            shortName = shortName,
            logo = club.logo.copy(
                shape = shape,
                emblem = emblem,
                primaryColor = primary,
                accentColor = accent,
                shortName = shortName
            )
        )
        // sync with league table row
        updateLeagueUserTeamName(club.name, shortName)
    }

    fun updateClubName(name: String) {
        club = club.copy(name = name)
        updateLeagueUserTeamName(name, club.shortName)
    }

    private fun updateLeagueUserTeamName(name: String, shortName: String) {
        leagueTable = leagueTable.map {
            if (it.isUserTeam) it.copy(teamName = name, shortName = shortName) else it
        }
    }

    // CREATE CUSTOM PLAYER
    fun saveCustomPlayer(
        name: String,
        nickname: String,
        position: Position,
        number: Int,
        preferredFoot: String,
        pace: Int,
        shooting: Int,
        passing: Int,
        dribbling: Int,
        defending: Int,
        physical: Int,
        skill: String,
        avatarColor: Long
    ): Player {
        val id = customPlayer?.id ?: "custom_player_${System.currentTimeMillis()}"
        val created = Player(
            id = id,
            name = name,
            nickname = nickname,
            position = position,
            number = number,
            age = 22,
            preferredFoot = preferredFoot,
            ovr = 0, // calculated below
            pace = pace,
            shooting = shooting,
            passing = passing,
            dribbling = dribbling,
            defending = defending,
            physical = physical,
            signatureSkill = skill,
            isCustom = true,
            customAvatarColor = avatarColor,
            marketValue = 3_000_000L,
            wage = 30_000L,
            stats = customPlayer?.stats ?: PlayerStats()
        )
        val finalPlayer = created.copy(ovr = created.calculateOvr())
        customPlayer = finalPlayer

        // Update squad: replace existing custom player or add
        val existingIndex = squad.indexOfFirst { it.id == id }
        val newSquad = squad.toMutableList()
        if (existingIndex != -1) {
            newSquad[existingIndex] = finalPlayer
        } else {
            newSquad.add(finalPlayer)
        }
        squad = newSquad

        // Auto put custom player in starting 7 if not there
        if (id !in startingSevenIds) {
            val newStarters = startingSevenIds.toMutableList()
            // replace non-GK if possible
            val replaceIdx = newStarters.indexOfLast { starterId ->
                val p = squad.find { it.id == starterId }
                p?.position == position || (p?.position != Position.GK && position != Position.GK)
            }
            if (replaceIdx != -1) {
                newStarters[replaceIdx] = id
                startingSevenIds = newStarters
            }
        }

        return finalPlayer
    }

    // STADIUM UPGRADE & FACILITIES
    fun upgradeStadium(): Boolean {
        val nextTier = when (club.stadiumTier) {
            StadiumTier.GRASSROOTS -> StadiumTier.FLOODLIGHT_ARENA
            StadiumTier.FLOODLIGHT_ARENA -> StadiumTier.COVERED_STADIUM
            StadiumTier.COVERED_STADIUM -> StadiumTier.GRAND_NATIONAL
            StadiumTier.GRAND_NATIONAL -> null
        } ?: return false

        if (club.budget >= nextTier.upgradeCost) {
            club = club.copy(
                budget = club.budget - nextTier.upgradeCost,
                stadiumTier = nextTier,
                fanbase = club.fanbase.copy(
                    fanCount = club.fanbase.fanCount + (nextTier.capacity * 2),
                    loyaltyLevel = (club.fanbase.loyaltyLevel + 1).coerceAtMost(5)
                )
            )
            return true
        }
        return false
    }

    fun purchaseFacility(facilityId: String): Boolean {
        val fac = club.facilities.find { it.id == facilityId } ?: return false
        if (fac.isOwned || club.budget < fac.cost) return false

        val updatedFacilities = club.facilities.map {
            if (it.id == facilityId) it.copy(isOwned = true) else it
        }
        club = club.copy(
            budget = club.budget - fac.cost,
            facilities = updatedFacilities,
            fanbase = club.fanbase.copy(
                fanCount = club.fanbase.fanCount + 1500,
                merchandiseRevenueRate = club.fanbase.merchandiseRevenueRate + 15000
            )
        )
        return true
    }

    // FANBASE ACTIONS
    fun launchFanCampaign(campaignType: String): Boolean {
        val cost = when (campaignType) {
            "MEET_AND_GREET" -> 100_000L
            "SOCIAL_ADS" -> 250_000L
            "JERSEY_GIVEAWAY" -> 400_000L
            else -> 100_000L
        }
        if (club.budget < cost) return false

        val fanGained = when (campaignType) {
            "MEET_AND_GREET" -> 1_200
            "SOCIAL_ADS" -> 3_500
            "JERSEY_GIVEAWAY" -> 5_800
            else -> 1_000
        }
        club = club.copy(
            budget = club.budget - cost,
            fanbase = club.fanbase.copy(
                fanCount = club.fanbase.fanCount + fanGained,
                loyaltyLevel = (club.fanbase.loyaltyLevel + (if (campaignType == "JERSEY_GIVEAWAY") 1 else 0)).coerceAtMost(5)
            )
        )
        return true
    }

    // TRAINING DRILLS
    fun runTrainingDrill(drillType: String, targetPlayerId: String? = null): String {
        val cost = 50_000L
        if (club.budget < cost) return "งบประมาณสโมสรไม่เพียงพอสำหรับการฝึกซ้อม"

        val hasAcademy = club.facilities.find { it.id == "center" }?.isOwned == true
        val boost = if (hasAcademy) 2 else 1

        if (targetPlayerId != null) {
            // Train individual player
            val p = squad.find { it.id == targetPlayerId } ?: return "ไม่พบนักเตะ"
            val updated = when (drillType) {
                "SHOOTING" -> p.copy(shooting = (p.shooting + boost).coerceAtMost(99))
                "PACE" -> p.copy(pace = (p.pace + boost).coerceAtMost(99), stamina = (p.stamina + 5).coerceAtMost(100))
                "PASSING" -> p.copy(passing = (p.passing + boost).coerceAtMost(99), dribbling = (p.dribbling + boost).coerceAtMost(99))
                "DEFENDING" -> p.copy(defending = (p.defending + boost).coerceAtMost(99), physical = (p.physical + boost).coerceAtMost(99))
                else -> p
            }
            val finalUpdated = updated.copy(ovr = updated.calculateOvr())
            squad = squad.map { if (it.id == targetPlayerId) finalUpdated else it }
            club = club.copy(budget = club.budget - cost)
            return "ฝึกซ้อม ${p.name} สำเร็จ! ค่าพลังเพิ่มขึ้น (OVR: ${finalUpdated.ovr})"
        } else {
            // Team Drill
            squad = squad.map { p ->
                val up = when (drillType) {
                    "SHOOTING" -> p.copy(shooting = (p.shooting + 1).coerceAtMost(99))
                    "PACE" -> p.copy(pace = (p.pace + 1).coerceAtMost(99))
                    "PASSING" -> p.copy(passing = (p.passing + 1).coerceAtMost(99))
                    "DEFENDING" -> p.copy(defending = (p.defending + 1).coerceAtMost(99))
                    else -> p
                }
                up.copy(ovr = up.calculateOvr())
            }
            club = club.copy(budget = club.budget - cost)
            return "ฝึกซ้อมทั้งทีมสำเร็จ! ค่าพลังของนักเตะทุกคนในทีมพัฒนาขึ้น"
        }
    }

    // TRANSFER MARKET
    fun buyPlayer(player: Player): Boolean {
        if (club.budget < player.marketValue) return false

        club = club.copy(budget = club.budget - player.marketValue)
        squad = squad + player
        transferMarket = transferMarket.filter { it.id != player.id }
        return true
    }

    fun sellPlayer(playerId: String): Boolean {
        val player = squad.find { it.id == playerId } ?: return false
        if (squad.size <= 8) return false // maintain minimum squad size
        if (player.isCustom) return false // keep custom player

        club = club.copy(budget = club.budget + player.marketValue)
        squad = squad.filter { it.id != playerId }
        startingSevenIds = startingSevenIds.filter { it != playerId }

        // If removed from starting seven, promote bench player
        if (startingSevenIds.size < 7) {
            val nextBench = squad.firstOrNull { it.id !in startingSevenIds }
            if (nextBench != null) {
                startingSevenIds = startingSevenIds + nextBench.id
            }
        }
        return true
    }

    // MATCH ENGINE & REAL-TIME SIMULATION
    fun startNewMatch(opponent: MatchOpponent) {
        matchJob?.cancel()
        _matchState.value = LiveMatchState(
            opponent = opponent,
            homeScore = 0,
            awayScore = 0,
            currentMinute = 0,
            half = 1,
            isPlaying = true,
            isFinished = false,
            ballX = 50f,
            ballY = 50f,
            possessionHome = true,
            activePlayerName = getStarters().firstOrNull { it.position == Position.MF }?.name ?: "เจ ชนาธิป"
        )

        commentarySpeaker.playWhistle()
        val kickoffMsg = ThaiCommentarySpeaker.getRandomPhrase(CommentaryType.KICKOFF)
        addCommentary(0, kickoffMsg, CommentaryType.KICKOFF, true)
        commentarySpeaker.speak(kickoffMsg)

        runMatchLoop()
    }

    fun pauseMatch() {
        _matchState.value = _matchState.value.copy(isPlaying = false)
        matchJob?.cancel()
    }

    fun resumeMatch() {
        if (_matchState.value.isFinished) return
        _matchState.value = _matchState.value.copy(isPlaying = true)
        runMatchLoop()
    }

    private fun runMatchLoop() {
        matchJob?.cancel()
        matchJob = scope.launch {
            while (isActive && _matchState.value.isPlaying && !_matchState.value.isFinished) {
                delay(1200L) // 1.2s per match minute tick

                val current = _matchState.value
                val nextMinute = current.currentMinute + 1

                if (nextMinute == 25 && current.half == 1) {
                    // Halftime break
                    commentarySpeaker.playWhistle()
                    val htMsg = ThaiCommentarySpeaker.getRandomPhrase(CommentaryType.HALFTIME)
                    addCommentary(25, htMsg, CommentaryType.HALFTIME, true)
                    commentarySpeaker.speak(htMsg)
                    _matchState.value = current.copy(
                        currentMinute = 25,
                        half = 2,
                        ballX = 50f,
                        ballY = 50f
                    )
                    delay(2000L)
                    continue
                }

                if (nextMinute > 50) {
                    // Fulltime end
                    finishMatch()
                    break
                }

                // Simulate play tick
                simulateMatchTick(nextMinute)
            }
        }
    }

    private fun simulateMatchTick(minute: Int) {
        val state = _matchState.value
        val starters = getStarters()
        val myTeamAvgOvr = if (starters.isNotEmpty()) starters.map { it.ovr }.average().toInt() else 85
        val oppOvr = state.opponent.ovr

        // Tactical boosts
        val tacticBonus = when (club.tactics.playStyle) {
            PlayStyle.TIKI_TAKA -> 3
            PlayStyle.HIGH_PRESS -> 4
            PlayStyle.FAST_COUNTER -> 2
            else -> 0
        }

        val myWeight = (myTeamAvgOvr + tacticBonus).toFloat()
        val oppWeight = oppOvr.toFloat()
        val homePossession = Random.nextFloat() < (myWeight / (myWeight + oppWeight))

        // Ball position dynamic simulation (0..100)
        val targetX = if (homePossession) {
            Random.nextInt(55, 95).toFloat()
        } else {
            Random.nextInt(5, 45).toFloat()
        }
        val targetY = Random.nextInt(20, 80).toFloat()

        val activePlayer = if (homePossession) {
            starters.filter { it.position != Position.GK }.randomOrNull() ?: starters.first()
        } else {
            null
        }

        // Check for major events
        val eventRoll = Random.nextInt(100)

        if (eventRoll < 12) {
            // Chance/Shot event!
            val isHomeShot = homePossession
            if (isHomeShot) {
                handleHomeChance(minute, activePlayer ?: starters.random())
            } else {
                handleAwayChance(minute)
            }
        } else if (eventRoll < 22) {
            // Dribble / Skill event
            val dribbler = activePlayer ?: starters.random()
            val text = ThaiCommentarySpeaker.getRandomPhrase(CommentaryType.DRIBBLE, dribbler.name)
            addCommentary(minute, text, CommentaryType.DRIBBLE, homePossession)
            // Speak occasional skill moves
            if (Random.nextBoolean()) {
                commentarySpeaker.speak(text)
            }
            _matchState.value = _matchState.value.copy(
                currentMinute = minute,
                ballX = targetX,
                ballY = targetY,
                possessionHome = homePossession,
                activePlayerName = dribbler.name
            )
        } else if (eventRoll < 35) {
            // Tackle / Interception event
            val tackler = starters.filter { it.position == Position.DF || it.position == Position.MF }.randomOrNull() ?: starters.random()
            val text = ThaiCommentarySpeaker.getRandomPhrase(CommentaryType.TACKLE, tackler.name)
            addCommentary(minute, text, CommentaryType.TACKLE, true)
            _matchState.value = _matchState.value.copy(
                currentMinute = minute,
                ballX = targetX,
                ballY = targetY,
                possessionHome = true,
                activePlayerName = tackler.name,
                homeStats = _matchState.value.homeStats.copy(tackles = _matchState.value.homeStats.tackles + 1)
            )
        } else {
            // Standard passing build up
            val passer = activePlayer ?: starters.random()
            _matchState.value = _matchState.value.copy(
                currentMinute = minute,
                ballX = targetX,
                ballY = targetY,
                possessionHome = homePossession,
                activePlayerName = if (homePossession) passer.name else state.opponent.starPlayer,
                homeStats = if (homePossession) {
                    _matchState.value.homeStats.copy(passes = _matchState.value.homeStats.passes + 1)
                } else _matchState.value.homeStats
            )
        }
    }

    // USER INTERACTIVE CONTROLS DURING MATCH
    fun userTriggerShoot() {
        val state = _matchState.value
        if (!state.isPlaying || state.isFinished) return
        val minute = state.currentMinute

        val starters = getStarters()
        val shooter = starters.filter { it.position == Position.FW || it.position == Position.MF }.randomOrNull() ?: starters.first()

        val shotRating = shooter.shooting + (if (shooter.isCustom) 5 else 0)
        val roll = Random.nextInt(100)

        val updatedHomeStats = state.homeStats.copy(
            shots = state.homeStats.shots + 1,
            shotsOnTarget = state.homeStats.shotsOnTarget + 1
        )

        if (roll < (shotRating * 0.45).toInt()) {
            // GOAL!
            handleGoal(minute, shooter, null, true)
        } else if (roll < 75) {
            // Great Save!
            val saveText = ThaiCommentarySpeaker.getRandomPhrase(CommentaryType.SAVE)
            addCommentary(minute, "${shooter.name} ซัดไกลเต็มแรง! $saveText", CommentaryType.SAVE, true)
            commentarySpeaker.speak("สับไกเต็มข้อ! $saveText")
            _matchState.value = state.copy(
                homeStats = updatedHomeStats,
                ballX = 90f,
                ballY = 50f
            )
        } else {
            // Woodwork!
            val woodText = ThaiCommentarySpeaker.getRandomPhrase(CommentaryType.WOODWORK)
            addCommentary(minute, "${shooter.name} กดเต็มข้อ! $woodText", CommentaryType.WOODWORK, true)
            commentarySpeaker.speak(woodText)
            _matchState.value = state.copy(
                homeStats = updatedHomeStats,
                ballX = 85f,
                ballY = 45f
            )
        }
    }

    fun userTriggerThroughPass() {
        val state = _matchState.value
        if (!state.isPlaying || state.isFinished) return
        val minute = state.currentMinute

        val starters = getStarters()
        val passer = starters.filter { it.position == Position.MF }.randomOrNull() ?: starters.first()
        val receiver = starters.filter { it.position == Position.FW }.randomOrNull() ?: starters.last()

        val passText = "${passer.name} แทงบอลทะลุช่องสุดเฉียบขาดให้ ${receiver.name} หลุดเดี่ยวเข้าไปในกรอบเขตโทษ!"
        addCommentary(minute, passText, CommentaryType.PASS, true)
        commentarySpeaker.speak("แทงทะลุช่องงามหยด หลุดเดี่ยวแล้วครับ!")

        _matchState.value = state.copy(
            ballX = 85f,
            ballY = 50f,
            possessionHome = true,
            activePlayerName = receiver.name,
            homeStats = state.homeStats.copy(passes = state.homeStats.passes + 2)
        )
    }

    fun userTriggerHighPress() {
        val state = _matchState.value
        if (!state.isPlaying || state.isFinished) return
        val minute = state.currentMinute

        val starters = getStarters()
        val tackler = starters.filter { it.position == Position.DF || it.position == Position.MF }.randomOrNull() ?: starters.first()

        val pressText = "${tackler.name} วิ่งบีบเพรสซิ่งสูง แย่งบอลสำเร็จอย่างดุดัน บอลกลับมาเป็นของเรา!"
        addCommentary(minute, pressText, CommentaryType.TACKLE, true)
        commentarySpeaker.speak("เพรสซิ่งแย่งบอลได้สวย สวนกลับทันที!")

        _matchState.value = state.copy(
            ballX = 65f,
            ballY = 50f,
            possessionHome = true,
            activePlayerName = tackler.name,
            homeStats = state.homeStats.copy(tackles = state.homeStats.tackles + 1)
        )
    }

    private fun handleHomeChance(minute: Int, shooter: Player) {
        val state = _matchState.value
        val shotProb = shooter.shooting
        val roll = Random.nextInt(100)

        val updatedStats = state.homeStats.copy(
            shots = state.homeStats.shots + 1,
            shotsOnTarget = state.homeStats.shotsOnTarget + if (roll < 80) 1 else 0
        )

        if (roll < (shotProb * 0.35).toInt()) {
            val assister = getStarters().filter { it.id != shooter.id }.randomOrNull()
            handleGoal(minute, shooter, assister, true)
        } else if (roll < 70) {
            val saveText = ThaiCommentarySpeaker.getRandomPhrase(CommentaryType.SAVE)
            addCommentary(minute, "${shooter.name} ได้โอกาสสับไก! $saveText", CommentaryType.SAVE, true)
            _matchState.value = state.copy(homeStats = updatedStats, ballX = 85f, ballY = 50f)
        } else {
            val shotText = ThaiCommentarySpeaker.getRandomPhrase(CommentaryType.SHOT, shooter.name)
            addCommentary(minute, shotText, CommentaryType.SHOT, true)
            _matchState.value = state.copy(homeStats = updatedStats, ballX = 88f, ballY = 60f)
        }
    }

    private fun handleAwayChance(minute: Int) {
        val state = _matchState.value
        val opp = state.opponent
        val roll = Random.nextInt(100)

        val updatedStats = state.awayStats.copy(
            shots = state.awayStats.shots + 1,
            shotsOnTarget = state.awayStats.shotsOnTarget + if (roll < 75) 1 else 0
        )

        if (roll < (opp.ovr * 0.25).toInt()) {
            handleGoal(minute, null, null, false)
        } else {
            // My GK saves!
            val myGk = getStarters().find { it.position == Position.GK } ?: squad.first()
            val saveText = ThaiCommentarySpeaker.getRandomPhrase(CommentaryType.SAVE)
            addCommentary(minute, "${opp.starPlayer} ยิงจ่อๆ แต่ ${myGk.name} $saveText", CommentaryType.SAVE, true)
            commentarySpeaker.speak("${myGk.nickname} ซูเปอร์เซฟระดับพระกาฬ!")
            _matchState.value = state.copy(
                awayStats = updatedStats,
                ballX = 15f,
                ballY = 50f,
                possessionHome = true,
                activePlayerName = myGk.name
            )
        }
    }

    private fun handleGoal(minute: Int, scorer: Player?, assister: Player?, isHome: Boolean) {
        val state = _matchState.value
        val scorerName = scorer?.name ?: state.opponent.starPlayer
        val goalEvent = GoalEvent(
            minute = minute,
            scorerName = scorerName,
            assistName = assister?.name,
            isHomeTeam = isHome
        )

        val newHomeScore = if (isHome) state.homeScore + 1 else state.homeScore
        val newAwayScore = if (!isHome) state.awayScore + 1 else state.awayScore

        val goalCommentary = ThaiCommentarySpeaker.getRandomPhrase(CommentaryType.GOAL, scorerName)
        addCommentary(minute, goalCommentary, CommentaryType.GOAL, isHome)

        // Broadcast commentary voice
        commentarySpeaker.speak(goalCommentary, isGoal = true)

        // Update player individual stats
        if (isHome && scorer != null) {
            squad = squad.map { p ->
                if (p.id == scorer.id) {
                    p.copy(stats = p.stats.copy(goals = p.stats.goals + 1, shotsOnTarget = p.stats.shotsOnTarget + 1))
                } else if (assister != null && p.id == assister.id) {
                    p.copy(stats = p.stats.copy(assists = p.stats.assists + 1))
                } else p
            }
        }

        _matchState.value = state.copy(
            homeScore = newHomeScore,
            awayScore = newAwayScore,
            currentMinute = minute,
            goals = state.goals + goalEvent,
            ballX = 50f,
            ballY = 50f,
            homeStats = if (isHome) state.homeStats.copy(shots = state.homeStats.shots + 1, shotsOnTarget = state.homeStats.shotsOnTarget + 1) else state.homeStats,
            awayStats = if (!isHome) state.awayStats.copy(shots = state.awayStats.shots + 1, shotsOnTarget = state.awayStats.shotsOnTarget + 1) else state.awayStats
        )
    }

    private fun addCommentary(minute: Int, text: String, type: CommentaryType, isHome: Boolean) {
        val item = CommentaryItem(minute, text, type, isHome)
        _matchState.value = _matchState.value.copy(
            commentaryHistory = listOf(item) + _matchState.value.commentaryHistory.take(40),
            latestCommentary = item
        )
    }

    private fun finishMatch() {
        val state = _matchState.value
        commentarySpeaker.playWhistle()
        val ftMsg = ThaiCommentarySpeaker.getRandomPhrase(CommentaryType.FULLTIME)
        addCommentary(50, ftMsg, CommentaryType.FULLTIME, true)
        commentarySpeaker.speak(ftMsg)

        val won = state.homeScore > state.awayScore
        val drawn = state.homeScore == state.awayScore

        // Calculate Match Financial Rewards & Fan Boost
        val prizeMoney = if (won) 350_000L else if (drawn) 120_000L else 40_000L
        val ticketIncome = (club.stadiumTier.capacity * club.stadiumTier.ticketPrice * 0.85f).toLong()
        val totalMatchIncome = prizeMoney + ticketIncome

        val newFanGain = if (won) 1500 else if (drawn) 400 else 100

        club = club.copy(
            budget = club.budget + totalMatchIncome,
            fanbase = club.fanbase.copy(fanCount = club.fanbase.fanCount + newFanGain)
        )

        // Update squad matches played
        val starterIdsSet = startingSevenIds.toSet()
        squad = squad.map { p ->
            if (p.id in starterIdsSet) {
                val isGkClean = p.position == Position.GK && state.awayScore == 0
                p.copy(
                    stats = p.stats.copy(
                        matchesPlayed = p.stats.matchesPlayed + 1,
                        cleanSheets = p.stats.cleanSheets + (if (isGkClean) 1 else 0),
                        averageRating = ((p.stats.averageRating * p.stats.matchesPlayed) + (if (won) 8.2f else 6.8f)) / (p.stats.matchesPlayed + 1)
                    )
                )
            } else p
        }

        // Update League Table
        updateLeagueAfterMatch(state.homeScore, state.awayScore, state.opponent)

        _matchState.value = state.copy(
            currentMinute = 50,
            isPlaying = false,
            isFinished = true
        )
    }

    private fun updateLeagueAfterMatch(myScore: Int, oppScore: Int, opponent: MatchOpponent) {
        val myWon = myScore > oppScore
        val myDrawn = myScore == oppScore
        val myLost = myScore < oppScore

        leagueTable = leagueTable.map { row ->
            if (row.isUserTeam) {
                row.copy(
                    played = row.played + 1,
                    won = row.won + (if (myWon) 1 else 0),
                    drawn = row.drawn + (if (myDrawn) 1 else 0),
                    lost = row.lost + (if (myLost) 1 else 0),
                    goalsFor = row.goalsFor + myScore,
                    goalsAgainst = row.goalsAgainst + oppScore,
                    goalDiff = (row.goalsFor + myScore) - (row.goalsAgainst + oppScore),
                    points = row.points + (if (myWon) 3 else if (myDrawn) 1 else 0)
                )
            } else if (row.shortName == opponent.shortName) {
                row.copy(
                    played = row.played + 1,
                    won = row.won + (if (myLost) 1 else 0),
                    drawn = row.drawn + (if (myDrawn) 1 else 0),
                    lost = row.lost + (if (myWon) 1 else 0),
                    goalsFor = row.goalsFor + oppScore,
                    goalsAgainst = row.goalsAgainst + myScore,
                    goalDiff = (row.goalsFor + oppScore) - (row.goalsAgainst + myScore),
                    points = row.points + (if (myLost) 3 else if (myDrawn) 1 else 0)
                )
            } else row
        }.sortedWith(compareByDescending<LeagueTeamRow> { it.points }.thenByDescending { it.goalDiff }.thenByDescending { it.goalsFor })
            .mapIndexed { index, row -> row.copy(rank = index + 1) }

        // Update Top Scorers List
        val topPlayer = squad.maxByOrNull { it.stats.goals }
        if (topPlayer != null && topPlayer.stats.goals > 0) {
            topScorers = (topScorers.filter { !it.isUserPlayer } + TopScorerEntry(
                rank = 1,
                playerName = topPlayer.name,
                teamName = club.name,
                goals = topPlayer.stats.goals,
                assists = topPlayer.stats.assists,
                matches = topPlayer.stats.matchesPlayed,
                isUserPlayer = true
            )).sortedByDescending { it.goals }.mapIndexed { index, entry -> entry.copy(rank = index + 1) }
        }
    }

    fun destroy() {
        commentarySpeaker.shutdown()
    }
}
