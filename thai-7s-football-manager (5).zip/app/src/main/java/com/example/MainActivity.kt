package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.example.data.GameStateManager
import com.example.ui.screens.MainAppScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.StadiumDarkBg

class MainActivity : ComponentActivity() {

    private lateinit var gameStateManager: GameStateManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        gameStateManager = GameStateManager(applicationContext)

        setContent {
            MyApplicationTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = StadiumDarkBg
                ) {
                    MainAppScreen(gameStateManager = gameStateManager)
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (::gameStateManager.isInitialized) {
            gameStateManager.destroy()
        }
    }
}
