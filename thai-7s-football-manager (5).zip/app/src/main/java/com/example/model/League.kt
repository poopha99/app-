package com.example.model

data class LeagueTeamRow(
    val rank: Int,
    val teamName: String,
    val shortName: String,
    val badgeColor: Long,
    val played: Int,
    val won: Int,
    val drawn: Int,
    val lost: Int,
    val goalsFor: Int,
    val goalsAgainst: Int,
    val goalDiff: Int,
    val points: Int,
    val isUserTeam: Boolean = false
)

data class TopScorerEntry(
    val rank: Int,
    val playerName: String,
    val teamName: String,
    val goals: Int,
    val assists: Int,
    val matches: Int,
    val isUserPlayer: Boolean = false
)
