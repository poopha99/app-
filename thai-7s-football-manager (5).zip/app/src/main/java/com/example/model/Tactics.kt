package com.example.model

enum class FormationType(val label: String, val pattern: String, val desc: String) {
    F_2_3_1("2 - 3 - 1", "2-3-1", "สมดุลมาตรฐานยอดนิยม คุมแดนกลาง 3 คน"),
    F_3_2_1("3 - 2 - 1", "3-2-1", "รับแน่น โต้กลับเร็ว เหมาะเจอยอดทีม"),
    F_2_2_2("2 - 2 - 2", "2-2-2", "รุกดุดัน กองหน้าคู่กดดันแผงหลัง"),
    F_1_3_2("1 - 3 - 2", "1-3-2", "เปิดเกมรุกเต็มสูบ ท้าแลกหมัด"),
    F_2_1_2_1("2 - 1 - 2 - 1", "2-1-2-1", "ระบบไดมอนด์ เคาะบอลสั้นตามช่อง")
}

enum class PlayStyle(val thName: String, val boostDesc: String) {
    TIKI_TAKA("ติ๊กกี้-ตาก้า เคาะสั้น", "เพิ่มความแม่นยำการส่งบอล +15%"),
    FAST_COUNTER("สวนกลับสายฟ้าแลบ", "เพิ่มความเร็วสปีดโต้กลับ +20%"),
    HIGH_PRESS("เพรสซิ่งสูงแดนบน", "เพิ่มโอกาสตัดบอลแดนหน้า +25% แต่กินแรง"),
    DIRECT_ATTACK("เปิดบอลยาวโจมตีเร็ว", "เน้นแทงบอลเร็วให้กองหน้าจบสกอร์"),
    PARK_THE_BUS("แพ็กเกมรับลึก", "ลดโอกาสเสียประตู +30%")
}

data class TacticsConfig(
    val formation: FormationType = FormationType.F_2_3_1,
    val playStyle: PlayStyle = PlayStyle.TIKI_TAKA,
    val gameTempo: Int = 75, // 1..100
    val pressingIntensity: Int = 70, // 1..100
    val pitchWidth: Int = 60, // 1..100
    val captainId: String = "",
    val penaltyTakerId: String = "",
    val freekickTakerId: String = "",
    val cornerTakerId: String = ""
)
