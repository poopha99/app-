package com.example.model

enum class StadiumTier(
    val title: String,
    val capacity: Int,
    val upgradeCost: Long,
    val ticketPrice: Int,
    val description: String
) {
    GRASSROOTS("สนามหญ้าเทียมชุมชน 7 คน", 800, 0L, 50, "สนามหญ้าเทียมมาตรฐาน มีอัฒจันทร์ไม้เรียบง่าย"),
    FLOODLIGHT_ARENA("ไนท์ไลท์ อารีน่า 7s", 2_500, 1_200_000L, 100, "ติดตั้งไฟสปอร์ตไลท์ HD สำหรับแข่งแมตช์กลางคืนสุดมันส์"),
    COVERED_STADIUM("ไทยซูเปอร์ อารีน่า มีหลังคา", 6_000, 3_500_000L, 180, "อัฒจันทร์คอนกรีตมีหลังคา จอ LED สกอร์บอร์ดขนาดใหญ่"),
    GRAND_NATIONAL("แกรนด์ สเตเดียม ฟุตบอล 7 คน", 12_000, 8_000_000L, 300, "สเตเดียมระดับประเทศ มาตรฐานจัดทัวร์นาเมนต์เงินล้านชิงแชมป์")
}

data class Facility(
    val id: String,
    val name: String,
    val cost: Long,
    val isOwned: Boolean,
    val bonusDescription: String,
    val iconName: String
)

data class Fanbase(
    val fanCount: Int = 12_500,
    val loyaltyLevel: Int = 3, // 1..5 (ดาวความภักดี)
    val seasonTicketHolders: Int = 450,
    val merchandiseRevenueRate: Int = 45_000 // ต่อสัปดาห์
)
