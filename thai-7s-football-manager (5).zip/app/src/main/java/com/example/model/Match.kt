package com.example.model

enum class CommentaryType {
    KICKOFF,
    PASS,
    DRIBBLE,
    SHOT,
    GOAL,
    SAVE,
    WOODWORK,
    TACKLE,
    FOUL,
    HALFTIME,
    FULLTIME
}

data class CommentaryItem(
    val minute: Int,
    val text: String,
    val type: CommentaryType,
    val isHomeEvent: Boolean = true
)

data class GoalEvent(
    val minute: Int,
    val scorerName: String,
    val assistName: String? = null,
    val isHomeTeam: Boolean
)

data class TeamMatchStats(
    val shots: Int = 0,
    val shotsOnTarget: Int = 0,
    val possessionPct: Int = 50,
    val passes: Int = 0,
    val tackles: Int = 0,
    val corners: Int = 0,
    val fouls: Int = 0
)

data class MatchOpponent(
    val id: String,
    val name: String,
    val shortName: String,
    val badgeColor: Long,
    val ovr: Int,
    val starPlayer: String,
    val city: String
)

data class LiveMatchState(
    val opponent: MatchOpponent,
    val homeScore: Int = 0,
    val awayScore: Int = 0,
    val currentMinute: Int = 0, // 0..50 mins (2x25 min halves for Thai 7-a-side)
    val half: Int = 1,
    val isPlaying: Boolean = false,
    val isFinished: Boolean = false,
    val ballX: Float = 50f, // 0..100% of pitch
    val ballY: Float = 50f, // 0..100% of pitch
    val possessionHome: Boolean = true,
    val activePlayerName: String = "เจ ชนาธิป",
    val homeStats: TeamMatchStats = TeamMatchStats(),
    val awayStats: TeamMatchStats = TeamMatchStats(),
    val goals: List<GoalEvent> = emptyList(),
    val commentaryHistory: List<CommentaryItem> = emptyList(),
    val latestCommentary: CommentaryItem? = null,
    val lastActionCooldown: Long = 0L
)
