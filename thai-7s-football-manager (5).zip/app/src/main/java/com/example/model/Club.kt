package com.example.model

enum class KitPattern(val label: String) {
    SOLID("สีพื้นคลาสสิก"),
    STRIPES("ลายทางตรง สไตล์บอลเดินสาย"),
    SASH("แถบเฉียงพาดอก"),
    HOOPS("ลายขวางทูโทน"),
    THAI_CHEVRON("ลายกนกเรขาคณิตไทย"),
    NEON_CYBER("นีออน ไซเบอร์ eFootball")
}

data class KitConfig(
    val primaryColor: Long = 0xFF0D47A1, // Deep Blue
    val secondaryColor: Long = 0xFFFFD600, // Gold Yellow
    val accentColor: Long = 0xFFFFFFFF,
    val numberColor: Long = 0xFFFFFFFF,
    val pattern: KitPattern = KitPattern.STRIPES,
    val customImageUri: String? = null // When user uploads their custom jersey photo
)

enum class LogoShape(val label: String) {
    SHIELD("โล่คลาสสิก"),
    CIRCLE("วงกลมโมเดิร์น"),
    DIAMOND("เพชรไดมอนด์"),
    HEXAGON("เฮกซากอนเหลี่ยมเพชร")
}

enum class LogoEmblem(val label: String) {
    ELEPHANT("ช้างศึกพญาคชสาร"),
    TIGER("เสือโคร่งลายพาดกลอน"),
    EAGLE("พญาอินทรีเหินเวหา"),
    DRAGON("พญานาคราชมังกร"),
    LIGHTNING("สายฟ้าฟาดพลังเทอร์โบ"),
    FOOTBALL("ลูกฟุตบอลเพลิง 7 คน")
}

data class LogoConfig(
    val shape: LogoShape = LogoShape.SHIELD,
    val emblem: LogoEmblem = LogoEmblem.ELEPHANT,
    val primaryColor: Long = 0xFF0D47A1,
    val accentColor: Long = 0xFFFFD600,
    val shortName: String = "SIA"
)

data class Club(
    val name: String = "สยาม วอริเออร์ 7s",
    val shortName: String = "SIA",
    val budget: Long = 6_500_000L,
    val stadiumTier: StadiumTier = StadiumTier.FLOODLIGHT_ARENA,
    val stadiumName: String = "สยาม 7s ซูเปอร์ อารีน่า",
    val fanbase: Fanbase = Fanbase(),
    val facilities: List<Facility> = listOf(
        Facility("light", "ระบบไฟส่องสว่าง HD ไนท์แมตช์", 800_000, true, "เพิ่มยอดผู้ชมเกมกลางคืน +20%", "lightbulb"),
        Facility("shop", "ช็อปขายเสื้อแข่ง & คาเฟ่แฟนบอล", 1_500_000, false, "เพิ่มรายได้ขายของที่ระลึก +40%", "storefront"),
        Facility("vip", "ห้องพักนักกีฬา & อ่างน้ำแข็งฟื้นฟู VIP", 2_000_000, false, "ฟื้นฟูความฟิตนักเตะหลังแข่งเร็วขึ้น 35%", "fitness_center"),
        Facility("center", "ศูนย์ฝึกซ้อมอะคาเดมี 7 คนมาตรฐาน", 3_000_000, false, "เพิ่มผลลัพธ์การฝึกซ้อม OVR +25%", "sports_soccer")
    ),
    val kit: KitConfig = KitConfig(),
    val logo: LogoConfig = LogoConfig(),
    val tactics: TacticsConfig = TacticsConfig()
)
