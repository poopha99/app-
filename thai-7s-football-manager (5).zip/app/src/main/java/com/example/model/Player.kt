package com.example.model

enum class Position(val thName: String, val shortName: String) {
    GK("ผู้รักษาประตู", "GK"),
    DF("กองหลัง", "DF"),
    MF("กองกลาง", "MF"),
    FW("กองหน้า", "FW")
}

data class PlayerStats(
    val matchesPlayed: Int = 0,
    val goals: Int = 0,
    val assists: Int = 0,
    val cleanSheets: Int = 0,
    val yellowCards: Int = 0,
    val redCards: Int = 0,
    val shotsOnTarget: Int = 0,
    val tacklesWon: Int = 0,
    val passesCompleted: Int = 0,
    val averageRating: Float = 7.0f
)

data class Player(
    val id: String,
    val name: String,
    val nickname: String,
    val position: Position,
    val number: Int,
    val age: Int,
    val heightCm: Int = 175,
    val preferredFoot: String = "ขวา", // ขวา, ซ้าย, สองเท้า
    val ovr: Int,
    val pace: Int,
    val shooting: Int,
    val passing: Int,
    val dribbling: Int,
    val defending: Int,
    val physical: Int,
    val stamina: Int = 100,
    val morale: String = "ฮึกเหิม", // ฮึกเหิม, ยอดเยี่ยม, ปกติ, เหนื่อยล้า
    val marketValue: Long = 500_000,
    val wage: Long = 12_000,
    val signatureSkill: String = "สปีดจัดจ้าน",
    val isCustom: Boolean = false,
    val customAvatarColor: Long = 0xFF2979FF,
    val stats: PlayerStats = PlayerStats()
) {
    fun calculateOvr(): Int {
        return when (position) {
            Position.GK -> ((defending * 0.4f) + (physical * 0.3f) + (passing * 0.3f)).toInt().coerceIn(50, 99)
            Position.DF -> ((defending * 0.45f) + (physical * 0.3f) + (pace * 0.25f)).toInt().coerceIn(50, 99)
            Position.MF -> ((passing * 0.35f) + (dribbling * 0.3f) + (shooting * 0.2f) + (pace * 0.15f)).toInt().coerceIn(50, 99)
            Position.FW -> ((shooting * 0.4f) + (pace * 0.3f) + (dribbling * 0.2f) + (physical * 0.1f)).toInt().coerceIn(50, 99)
        }
    }
}
