package com.example.audio

import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import com.example.model.CommentaryType
import java.util.Locale
import kotlin.random.Random

class ThaiCommentarySpeaker(private val context: Context) : TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = null
    private var isTtsReady = false
    var isMuted = false
    var speechRate: Float = 1.15f // A bit energetic for sports commentary!

    private val toneGenerator = try {
        ToneGenerator(AudioManager.STREAM_MUSIC, 80)
    } catch (e: Exception) {
        null
    }

    init {
        try {
            tts = TextToSpeech(context.applicationContext, this)
        } catch (e: Exception) {
            Log.e("ThaiCommentary", "TTS init error: ${e.message}")
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale("th", "TH"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                // Try generic Thai or default
                val resAlt = tts?.setLanguage(Locale("th"))
                isTtsReady = (resAlt != TextToSpeech.LANG_MISSING_DATA && resAlt != TextToSpeech.LANG_NOT_SUPPORTED)
            } else {
                isTtsReady = true
            }
            tts?.setSpeechRate(speechRate)
            tts?.setPitch(1.05f)
        }
    }

    fun playWhistle() {
        if (isMuted) return
        try {
            toneGenerator?.startTone(ToneGenerator.TONE_PROP_BEEP2, 350)
        } catch (e: Exception) {
            // ignore
        }
    }

    fun playGoalCheer() {
        if (isMuted) return
        try {
            toneGenerator?.startTone(ToneGenerator.TONE_CDMA_HIGH_PBX_L, 500)
        } catch (e: Exception) {
            // ignore
        }
    }

    fun shutdown() {
        try {
            tts?.stop()
            tts?.shutdown()
            toneGenerator?.release()
        } catch (e: Exception) {
            // ignore
        }
    }

    fun speak(text: String, isGoal: Boolean = false) {
        if (isMuted) return

        if (isGoal) {
            playGoalCheer()
        }

        if (isTtsReady && tts != null) {
            try {
                tts?.stop()
                val params = Bundle().apply {
                    putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, 1.0f)
                }
                tts?.speak(text, TextToSpeech.QUEUE_FLUSH, params, "commentary_${System.currentTimeMillis()}")
            } catch (e: Exception) {
                Log.e("ThaiCommentary", "Speak error: ${e.message}")
            }
        }
    }

    fun stop() {
        try {
            tts?.stop()
        } catch (e: Exception) {
            // ignore
        }
    }

    fun destroy() {
        try {
            tts?.stop()
            tts?.shutdown()
            toneGenerator?.release()
        } catch (e: Exception) {
            // ignore
        }
    }

    companion object {
        private val kickoffPhrases = listOf(
            "สวัสดีครับแฟนบอลทุกท่าน ยินดีต้อนรับสู่ศึกฟุตบอล 7 คนเดินสายเงินล้าน!",
            "เป่านกหวีดเริ่มเกมแล้วครับ ศึกแห่งศักดิ์ศรีบอล 7 คนเปิดฉากทันที!",
            "กรรมการเป่านกหวีดเริ่มเกม บอลเดินสายระดับประเทศเปิดฉากขึ้นแล้วครับท่านผู้ชม!"
        )

        private val passPhrases = listOf(
            "เคาะบอลสั้นตามช่อง สไตล์บอลเดินสาย 7 คน มองหาเพื่อนร่วมทีม!",
            "ดึงจังหวะหลอกหนึ่งที จ่ายทะลุช่องขึ้นหน้าอย่างแม่นยำ!",
            "ต่อบอลสั้นจังหวะเดียว เคาะไปรอบๆ หาช่องเจาะแนวรับ!",
            "แปะคืนหลังอย่างใจเย็น สลับแกนข้ามฟากไปทางกราบขวา!"
        )

        private val dribblePhrases = listOf(
            "โอ้โห กระชากหลบหนึ่ง หลบสอง ดึงเข้าเหลี่ยมเท้าถนัด!",
            "แตะลอดขาไปแล้วครับท่านผู้ชม คลึงบอลไวอย่างกับปรอท!",
            "โยกหลอกจนกองหลังเสียหลัก ทักษะเฉพาะตัวระดับเทพเดินสาย!",
            "สปีดติดเทอร์โบ กระชากฉีกแนวรับริมเส้นไปแบบไร้ตัวประกบ!"
        )

        private val shotPhrases = listOf(
            "สับไกนอกกรอบเต็มข้อ บอลพุ่งเป็นจรวด!",
            "ปั่นโค้งๆ บอลเลี้ยวจะเสียบสามเหลี่ยมเสาสอง!",
            "วอลเลย์ตูมเดียวไม่จับ ลุ้นระทึกกันทั้งสนาม!",
            "ยิงยัดเสาแรก กองเชียร์ลุกฮือขึ้นมาส่งเสียงเชียร์!"
        )

        private val goalPhrases = listOf(
            "เข้าประตูไปแล้วครับท่านผู้ชม!! โอ้โห ยิงดอกนี้งามหยด สะเทือนไปถึงดวงดาว!!",
            "ตุงตาข่ายหายวับ! กองเชียร์ลั่นสนาม แฟนคลับเฮสนั่น!",
            "คมกริบเหลือเชื่อ ยิงลูกนี้ระดับเวิลด์คลาสบอล 7 คนเงินล้าน!",
            "ซัดเปรี้ยงเดียวหายเข้าก้นตาข่าย! ยิงแบบนี้เอาช็อตออฟเดอะเดย์ไปเลยครับ!"
        )

        private val savePhrases = listOf(
            "โกล์บินปัดปลายมือ ซูเปอร์เซฟระดับพระกาฬ!",
            "ปัดทิ้งออกหลังไปได้อย่างเหลือเชื่อ เหนียวเหมือนทากาวตราช้าง!",
            "เซฟด้วยขาออกมาหวุดหวิด เกือบเสียประตูแล้วครับท่านผู้ชม!",
            "นายทวารพุ่งควักบอลออกจากเส้น ปาฏิหาริย์จริงๆ ครับ!"
        )

        private val woodworkPhrases = listOf(
            "ชนคานสนั่น เสาแทบหักครับท่านผู้ชม! น่าเสียดายจริงๆ!",
            "บอลชนเสาเด้งออกมา ช็อตนี้เกือบเป็นประตูขึ้นนำแล้ว!"
        )

        private val tacklePhrases = listOf(
            "เสียบสกัดเปรี้ยงเดียวติดพื้น กรรมการโบกมือบอกเล่นต่อ!",
            "ตัดบอลได้กลางสนาม สวนกลับเร็วทันที ระวังจังหวะนี้ให้ดี!",
            "ดักทางบอลอย่างเฉียบขาด ดับโอกาสเกมรุกคู่แข่งได้อยู่หมัด!"
        )

        private val foulPhrases = listOf(
            "โดนสอยร่วงลงไปนอนกับพื้น กรรมการเป่าฟาวล์ทันที!",
            "ตัดฟาวล์จังหวะอันตราย เสียฟรีคิกระยะทองคำหน้ากรอบเขตโทษ!"
        )

        private val halftimePhrases = listOf(
            "หมดครึ่งแรก สู้กันมันส์หยดติ๋ง พักดื่มน้ำวางแผนแก้เกมกันก่อนครับ!",
            "กรรมการเป่าหมดเวลา 25 นาทีแรก เกม 7 คนคุณภาพคับแก้วจริงๆ!"
        )

        private val fulltimePhrases = listOf(
            "หมดเวลาการแข่งขัน! ปิดฉากเกมฟุตบอล 7 คนสุดมันส์ แฟนบอลปรบมือลั่นสนาม!",
            "เป่านกหวีดยาวจบเกม ชัยชนะสุดประทับใจของยอดทีมฟุตบอล 7 คน!"
        )

        fun getRandomPhrase(type: CommentaryType, playerName: String? = null): String {
            val phrase = when (type) {
                CommentaryType.KICKOFF -> kickoffPhrases.random()
                CommentaryType.PASS -> {
                    if (playerName != null) "$playerName ${passPhrases.random()}" else passPhrases.random()
                }
                CommentaryType.DRIBBLE -> {
                    if (playerName != null) "$playerName ${dribblePhrases.random()}" else dribblePhrases.random()
                }
                CommentaryType.SHOT -> {
                    if (playerName != null) "$playerName ${shotPhrases.random()}" else shotPhrases.random()
                }
                CommentaryType.GOAL -> {
                    val base = goalPhrases.random()
                    if (playerName != null) "โกกกกกกกกกกกกกลลลล! $playerName ซัดเปรี้ยงเดียวเข้าประตูไปแล้ว! $base" else "เข้าประตูไปแล้ว! $base"
                }
                CommentaryType.SAVE -> savePhrases.random()
                CommentaryType.WOODWORK -> woodworkPhrases.random()
                CommentaryType.TACKLE -> {
                    if (playerName != null) "$playerName ${tacklePhrases.random()}" else tacklePhrases.random()
                }
                CommentaryType.FOUL -> foulPhrases.random()
                CommentaryType.HALFTIME -> halftimePhrases.random()
                CommentaryType.FULLTIME -> fulltimePhrases.random()
            }
            return phrase
        }
    }
}
